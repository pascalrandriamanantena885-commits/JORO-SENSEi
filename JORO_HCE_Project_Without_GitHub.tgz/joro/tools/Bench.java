package mg.chess.offline.own;

/**
 * Fandrefesana hafainganana/hery: java -cp cls mg.chess.offline.own.Bench [depth=9] [movetime=60]
 *  1) depth raikitra  -> nodes (famantarana ny fikarohana: miova rehefa ovaina ny search) sy nps
 *  2) fotoana raikitra (movetime ms) -> depth salanisa tratra, nps
 * Tsy ampiasain'ny app.
 */
public class Bench {
    static final String[] FENS = {
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
        "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
        "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
        "r1bq1rk1/pp2ppbp/2np1np1/8/3NP3/2N1BP2/PPPQ2PP/R3KB1R w KQ - 0 9",
        "2r2rk1/1bqnbpp1/1p1ppn1p/pP6/N1P1P3/P2B1N1P/1B2QPP1/R2R2K1 w - - 0 1",
        "8/5pk1/6p1/8/8/6P1/5PK1/8 w - - 0 1",
        "4k3/8/8/3p4/3P4/8/8/4K3 w - - 0 1",
        "r2q1rk1/ppp2ppp/2n1bn2/3pp3/1b1PP3/2NB1N2/PPP2PPP/R1BQ1RK1 b - - 0 8",
        "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1",
    };

    static Search fresh(String fen) {
        Search s = new Search(new Eval(50, 50, 50, 50, 50));
        s.setHash(Params.HASH_BITS.val);
        if (!s.pos.setFen(fen)) return null;
        return s;
    }

    public static void main(String[] a) {
        int depth = a.length > 0 ? Integer.parseInt(a[0]) : 9;
        long mt = a.length > 1 ? Long.parseLong(a[1]) : 60;
        for (int i = 2; i < a.length; i++) {       // safidy: Name=val (ohatra ProbCut=1)
            String[] kv = a[i].split("=");
            if (kv.length == 2 && Params.set(kv[0], Integer.parseInt(kv[1]))) System.out.println("OPTION " + a[i]);
            else System.out.println("OPTION TSY MARINA: " + a[i]);
        }

        // Fanamafisana JIT (tsy voaisa)
        for (String f : FENS) { Search s = fresh(f); if (s != null) s.think(64, 300); }

        for (int rep = 0; rep < 3; rep++) {
        long nodes = 0, spent = 0; int n = 0;
            for (String f : FENS) {
                Search s = fresh(f); if (s == null) { System.out.println("FEN diso: " + f); continue; }
                long c0 = System.nanoTime();
                Search.Result r = s.think(depth, 600_000);
                spent += System.nanoTime() - c0;
                nodes += r.nodes; n++;
                if (rep == 0) System.out.printf("  d%d  %-8s nodes=%d%n", depth, r.move == 0 ? "0000" : Pos.moveStr(r.move), r.nodes);
            }
            long ms = spent / 1_000_000L;
            System.out.printf("BENCH_DEPTH pass=%d depth=%d positions=%d nodes=%d time=%dms nps=%d%n",
                rep + 1, depth, n, nodes, ms, ms > 0 ? nodes * 1000L / ms : 0);
        }

        long tn = 0, tspent = 0; int td = 0, tc = 0;
        for (String f : FENS) {
            Search s = fresh(f); if (s == null) continue;
            long c0 = System.nanoTime();
            Search.Result r = s.think(64, mt);
            tspent += System.nanoTime() - c0;
            tn += r.nodes; td += r.depth; tc++;
        }
        long tms = tspent / 1_000_000L;
        System.out.printf("BENCH_TIME movetime=%dms positions=%d avg_depth=%.1f nodes=%d nps=%d%n",
            mt, tc, tc > 0 ? td / (double) tc : 0, tn, tms > 0 ? tn * 1000L / tms : 0);
    }
}
