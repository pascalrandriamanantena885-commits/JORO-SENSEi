package mg.chess.offline.own;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** UCI fohy ho an'ny fandrefesana (tools/calibrate.py). Tsy ampiasain'ny app. */
public class OwnUci {
    public static void main(String[] args) throws Exception {
        Search s = new Search(new Eval(50, 50, 50, 50, 50));
        int elo = 0;   // 0 = hery feno; > 0 = profile araka ny OwnBot.profile(elo) (calibrate --profile)
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.equals("uci")) {
                System.out.println("id name JORO");
                for (Params.P p : Params.ALL.values())
                    System.out.println("option name " + p.name + " type spin default " + p.def + " min " + p.min + " max " + p.max);
                System.out.println("option name Elo type spin default 0 min 0 max 3600");
                System.out.println("uciok");
            } else if (line.startsWith("setoption")) {
                String[] t = line.split("\\s+");
                String name = null; int val = 0;
                for (int i = 1; i < t.length - 1; i++) {
                    if (t[i].equals("name")) name = t[i + 1];
                    else if (t[i].equals("value")) { try { val = Integer.parseInt(t[i + 1]); } catch (NumberFormatException e) { name = null; } }
                }
                if ("Elo".equals(name)) elo = val;
                else if (name != null && Params.set(name, val) && name.equals("HashBits")) s.setHash(Params.HASH_BITS.val);
            }
            else if (line.equals("isready")) System.out.println("readyok");
            else if (line.equals("ucinewgame")) s.clear();
            else if (line.startsWith("position")) {
                String[] t = line.split("\\s+");
                int i = 1;
                if (t[i].equals("startpos")) { s.pos.setFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"); i++; }
                else { StringBuilder f = new StringBuilder(); i++; while (i < t.length && !t[i].equals("moves")) f.append(t[i++]).append(' '); s.pos.setFen(f.toString().trim()); }
                if (i < t.length && t[i].equals("moves")) for (i++; i < t.length; i++) s.pos.make(s.pos.parseMove(t[i]));
            } else if (line.startsWith("go")) {
                long ms = 1000;
                String[] t = line.split("\\s+");
                for (int i = 0; i < t.length - 1; i++) if (t[i].equals("movetime")) ms = Long.parseLong(t[i + 1]);
                Search.Result r = elo > 0 ? OwnBot.thinkFor(s, OwnBot.profile(elo), elo, ms) : s.think(64, ms);
                System.out.println("info depth " + r.depth + " score cp " + r.score + " nodes " + r.nodes);
                System.out.println("bestmove " + (r.move == 0 ? "0000" : Pos.moveStr(r.move)));
            } else if (line.equals("quit")) break;
            System.out.flush();
        }
    }
}
