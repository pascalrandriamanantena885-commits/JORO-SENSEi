package mg.chess.offline.own;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Mamoaka data Texel avy amin'ny lalao JORO vs JORO (ao anatin'ny Java, tsy mila python-chess).
 * Ampiasa: java -cp cls mg.chess.offline.own.SelfPlay <first> <games> <depth> <moveMs> <out> [threads=1] [openPlies=8]
 * Andalana: FEN;valiny_fotsy  (1.0 / 0.5 / 0.0), toerana milamina ihany (ply>=10, tsy check, tsy hetsika fakana).
 */
public class SelfPlay {
    static final char[] PC = {'?', 'p', 'n', 'b', 'r', 'q', 'k'};

    static String fen(Pos p) {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                int pc = p.b[r * 16 + f];
                if (pc == 0) { e++; continue; }
                if (e > 0) { sb.append(e); e = 0; }
                char c = PC[pc & 7];
                sb.append((pc >> 3) == 0 ? Character.toUpperCase(c) : c);
            }
            if (e > 0) sb.append(e);
            if (r > 0) sb.append('/');
        }
        sb.append(p.side == 0 ? " w " : " b ");
        String cs = "";
        if ((p.castle & 1) != 0) cs += "K";
        if ((p.castle & 2) != 0) cs += "Q";
        if ((p.castle & 4) != 0) cs += "k";
        if ((p.castle & 8) != 0) cs += "q";
        sb.append(cs.isEmpty() ? "-" : cs).append(' ');
        sb.append(p.ep >= 0 ? Pos.sqName(p.ep) : "-").append(" 0 1");
        return sb.toString();
    }

    static boolean hasLegal(Pos p) {
        int[] ms = new int[256];
        int n = p.genAll(ms);
        for (int i = 0; i < n; i++) if (p.make(ms[i])) { p.unmake(); return true; }
        return false;
    }

    static boolean insufficient(Pos p) {
        int minors = 0;
        for (int s = 0; s < 128; s++) {
            if ((s & 0x88) != 0) { s += 7; continue; }
            int t = p.b[s] & 7;
            if (p.b[s] == 0 || t == Pos.K) continue;
            if (t == Pos.P || t == Pos.R || t == Pos.Q) return false;
            minors++;
        }
        return minors <= 1;
    }

    static List<String> play(int g, int depth, long ms, int openPlies, Search s, Eval ev) {
        Random rng = new Random(0x5DEECE66DL * (g + 1));
        Pos p = s.pos;
        for (int attempt = 0; ; attempt++) {
            p.startPos();
            for (int i = 0; i < openPlies; i++) {
                int[] mv = new int[256];
                int n = p.genAll(mv);
                List<Integer> legal = new ArrayList<>();
                for (int k = 0; k < n; k++) if (p.make(mv[k])) { p.unmake(); legal.add(mv[k]); }
                if (legal.isEmpty()) break;
                p.make(legal.get(rng.nextInt(legal.size())));
            }
            if (Math.abs(ev.evalRaw(p)) <= 150 || attempt >= 30) break;
        }
        s.clear();
        int ply = openPlies, big = 0, bigSign = 0, quiet = 0;
        Double white = null;
        List<String> fens = new ArrayList<>();
        while (white == null) {
            if (!hasLegal(p)) { white = p.inCheck() ? (p.side == 0 ? 0.0 : 1.0) : 0.5; break; }
            if (p.half >= 100 || p.repeated() || insufficient(p) || ply >= 300) { white = 0.5; break; }
            boolean chk = p.inCheck();
            String f = fen(p);
            int side = p.side;
            Search.Result r = s.think(depth, ms);
            if (r.move == 0) { white = 0.5; break; }
            int sc = side == 0 ? r.score : -r.score;
            int to = Pos.to(r.move), from = Pos.from(r.move);
            boolean cap = p.b[to] != 0 || ((p.b[from] & 7) == Pos.P && (to & 7) != (from & 7));
            if (ply >= 10 && !chk && !cap && Pos.promo(r.move) == 0 && rng.nextBoolean()) fens.add(f);
            if (!p.make(r.move)) { white = 0.5; break; }
            ply++;
            if (Math.abs(sc) >= 900) {
                int sg = sc > 0 ? 1 : -1;
                big = (big > 0 && sg == bigSign) ? big + 1 : 1; bigSign = sg;
                if (big >= 6) white = sg > 0 ? 1.0 : 0.0;
            } else big = 0;
            quiet = Math.abs(sc) <= 15 ? quiet + 1 : 0;
            if (white == null && ply >= 160 && quiet >= 10) white = 0.5;
        }
        List<String> out = new ArrayList<>(fens.size());
        for (String f : fens) out.add(f + ";" + white);
        return out;
    }

    public static void main(String[] a) throws Exception {
        final int first = Integer.parseInt(a[0]), games = Integer.parseInt(a[1]);
        final int depth = Integer.parseInt(a[2]);
        final long ms = Long.parseLong(a[3]);
        final String out = a[4];
        final int threads = a.length > 5 ? Integer.parseInt(a[5]) : 1;
        final int openPlies = a.length > 6 ? Integer.parseInt(a[6]) : 8;
        final AtomicInteger next = new AtomicInteger(first), done = new AtomicInteger(), rows = new AtomicInteger();
        final PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(out)));
        ExecutorService ex = Executors.newFixedThreadPool(threads);
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < threads; t++) fs.add(ex.submit(() -> {
            Eval ev = new Eval(50, 50, 50, 50, 50);
            Search s = new Search(ev);
            while (true) {
                int g = next.getAndIncrement();
                if (g >= first + games) break;
                List<String> r = play(g, depth, ms, openPlies, s, ev);
                synchronized (pw) { for (String l : r) pw.println(l); pw.flush(); }
                rows.addAndGet(r.size());
                int d = done.incrementAndGet();
                if (d % 20 == 0) System.out.println(d + " lalao, " + rows.get() + " toerana");
            }
        }));
        for (Future<?> f : fs) f.get();
        ex.shutdown(); pw.close();
        System.out.println("SELFPLAY games=" + done.get() + " positions=" + rows.get() + " -> " + out);
    }
}
