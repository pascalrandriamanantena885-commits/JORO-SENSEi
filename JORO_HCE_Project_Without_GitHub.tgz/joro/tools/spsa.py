#!/usr/bin/env python3
"""SPSA: tuning ny parameter an'i JORO amin'ny alalan'ny lalao UCI (python-chess).

Fomba: isaky ny iteration, apetraka theta+ sy theta- (perturbation kisendrasendra +-c_k isaky ny parameter),
lalaovina `pairs` x 2 lalao (theta+ vs theta-), ary ovaina theta mankany amin'ny ilay nandresy.
Ny sisin'ny parameter (min/max/default) dia alaina avy amin'ny safidy UCI an'ny OwnUci (avy amin'ny Params.java).

Chain iray:  python3 tools/spsa.py <cls> --params '["RfpMargin","LmrBase"]' --chain 0 --iters 150 --pairs 6 --out spsa-0.json
Fitambarana: python3 tools/spsa.py --aggregate results
"""
import argparse, glob, json, math, os, random, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

ALPHA, GAMMA = 0.602, 0.101


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def to_real(u, lo, hi):
    return int(round(lo + clamp(u, 0.0, 1.0) * (hi - lo)))


def run_chain(play, spec, names, start, iters, lr, c0, seed, deadline=None, log=print, checkpoint=None):
    """play(plus:dict, minus:dict, k:int) -> score (0..1) an'ny `plus` amin'ny lalao `pairs`x2.
    spec: {name: (default, min, max)}. Miverina: dict(theta=..., last=..., hist=...)."""
    rng = random.Random(seed)
    u = {n: (clamp(float(start.get(n, spec[n][0])), spec[n][1], spec[n][2]) - spec[n][1]) / max(1, spec[n][2] - spec[n][1]) for n in names}
    A = max(1.0, iters * 0.1)
    hist, games_done, k = [], 0, 0
    for k in range(iters):
        if deadline and time.time() > deadline:
            log(f"[spsa] fe-potoana tapitra amin'ny iteration {k}")
            break
        ck = c0 / (k + 1) ** GAMMA
        ak = lr * ((A + 1) / (A + k + 1)) ** ALPHA
        plus, minus, d = {}, {}, {}
        for n in names:
            lo, hi = spec[n][1], spec[n][2]
            rng_range = max(1, hi - lo)
            delta = 1 if rng.random() < 0.5 else -1
            p = to_real(u[n] + ck * delta, lo, hi)
            m = to_real(u[n] - ck * delta, lo, hi)
            if p == m:                                  # tsy dia misaraka rehefa voahodikodina
                base = to_real(u[n], lo, hi)
                p, m = clamp(base + delta, lo, hi), clamp(base - delta, lo, hi)
            plus[n], minus[n] = p, m
            d[n] = (p - m) / rng_range                  # perturbation tena izy (normalized)
        s = play(plus, minus, k)
        games_done += 1
        y = s - 0.5                                     # >0: theta+ no tsara
        for n in names:
            if d[n] == 0:
                continue
            step = clamp(ak * y / d[n], -0.1, 0.1)
            u[n] = clamp(u[n] + step, 0.0, 1.0)
        hist.append(dict(u))
        cur = {n: to_real(u[n], spec[n][1], spec[n][2]) for n in names}
        log(f"[spsa] k={k + 1}/{iters} score(+)={s:.3f} ck={ck:.3f} ak={ak:.4f} theta={json.dumps(cur)}")
        if checkpoint:
            checkpoint(k + 1, hist, cur)
    tail = hist[max(0, len(hist) * 2 // 3):] or hist      # salanisa ny 1/3 farany (Polyak)
    avg = {n: (sum(h[n] for h in tail) / len(tail)) if tail else u[n] for n in names}
    theta = {n: to_real(avg[n], spec[n][1], spec[n][2]) for n in names}
    last = {n: to_real(u[n], spec[n][1], spec[n][2]) for n in names}
    return dict(theta=theta, last=last, iters=len(hist))


# ---------------------------------------------------------------- lalao tena izy
def _init_worker(cls, movetime, fixed):
    import sprt
    sprt._init(cls, cls, movetime, fixed, fixed)


def _game(args):
    import sprt
    g, plus, minus = args
    sprt._A["new"].configure(plus)
    sprt._A["old"].configure(minus)
    r = sprt.play_game(g)
    return r[1]                                         # valiny amin'ny fomba fijerin'ny "new" (= theta+)


def engine_spec(cls, names):
    import chess.engine
    eng = chess.engine.SimpleEngine.popen_uci(["java", "-cp", cls, "mg.chess.offline.own.OwnUci"])
    try:
        spec = {}
        for n in names:
            o = eng.options.get(n)
            if o is None or o.min is None or o.max is None:
                raise SystemExit(f"::error::Tsy hita ao amin'ny OwnUci ny safidy spin '{n}'")
            spec[n] = (int(o.default), int(o.min), int(o.max))
        return spec
    finally:
        eng.quit()


def aggregate(dirpath):
    files = sorted(glob.glob(os.path.join(dirpath, "**", "spsa-*.json"), recursive=True))
    if not files:
        print("::error::Tsy hita ny spsa-*.json"); sys.exit(1)
    rs = [json.load(open(f)) for f in files]
    names = list(rs[0]["theta"].keys())
    spec = rs[0]["spec"]
    lines, final = [], {}
    for n in names:
        vals = [r["theta"][n] for r in rs]
        mean = sum(vals) / len(vals)
        sd = math.sqrt(sum((v - mean) ** 2 for v in vals) / len(vals))
        final[n] = int(round(mean))
        lines.append(f"{n:14s} default={spec[n][0]:5d} -> {final[n]:5d}   (chain: {vals}, sd={sd:.1f}, [{spec[n][1]},{spec[n][2]}])")
    games = sum(r["iters"] * r["pairs"] * 2 for r in rs)
    changed = {n: v for n, v in final.items() if v != spec[n][0]}
    variant = ",".join(f"{n}={v}" for n, v in changed.items())
    out = [f"SPSA chain={len(rs)} lalao~{games}", *lines, "",
           f"SPRT variants: {json.dumps([variant])}",
           f"Hitohy: start={json.dumps(final)}"]
    txt = "\n".join(out)
    print(txt)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        open(os.environ["GITHUB_STEP_SUMMARY"], "a").write("### SPSA\n```\n" + txt + "\n```\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cls", nargs="?")
    ap.add_argument("--params", default='["RfpMargin","RfpMarginImp","RazorMargin","FutBase","FutMul","NmpBase","AspDelta","LmrBase","LmrDiv"]')
    ap.add_argument("--chain", type=int, default=0)
    ap.add_argument("--iters", type=int, default=150)
    ap.add_argument("--pairs", type=int, default=6, help="lalao isaky ny iteration = 2 x pairs")
    ap.add_argument("--movetime", type=int, default=100)
    ap.add_argument("--lr", type=float, default=0.05)
    ap.add_argument("--c", type=float, default=0.06, help="perturbation voalohany (normalized, 0..1 an'ny sakany)")
    ap.add_argument("--start", default="", help="JSON {anarana: sanda} ho an'ny fitohizana (avy amin'ny 'Hitohy')")
    ap.add_argument("--fixed", default="", help="safidy UCI tsy miova ho an'ny roa tonta: Name=val,Name2=val")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--max-minutes", type=float, default=300.0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="")
    ap.add_argument("--aggregate", default="")
    a = ap.parse_args()
    if a.aggregate:
        aggregate(a.aggregate); return
    from multiprocessing import Pool
    names = json.loads(a.params)
    spec = engine_spec(a.cls, names)
    start = json.loads(a.start) if a.start.strip() else {}
    n_games = 2 * a.pairs
    offset = a.chain * 10_000_000 + a.seed * 100_000
    deadline = time.time() + a.max_minutes * 60
    print(f"[spsa] chain={a.chain} params={names} spec={spec} start={start}", flush=True)
    with Pool(a.workers, initializer=_init_worker, initargs=(a.cls, a.movetime, a.fixed)) as pool:
        def play(plus, minus, k):
            first = offset + k * n_games
            res = pool.map(_game, [(first + i, plus, minus) for i in range(n_games)])
            return sum(res) / len(res)

        def checkpoint(k, hist, cur):
            if a.out:
                json.dump(dict(chain=a.chain, iters=k, pairs=a.pairs, theta=cur, spec=spec, partial=True), open(a.out, "w"))

        r = run_chain(play, spec, names, start, a.iters, a.lr, a.c, a.seed + a.chain, deadline, lambda s: print(s, flush=True), checkpoint)
    r.update(chain=a.chain, pairs=a.pairs, spec=spec)
    if a.out:
        json.dump(r, open(a.out, "w"))
    print("[spsa] vita:", json.dumps(r["theta"]))


if __name__ == "__main__":
    main()
