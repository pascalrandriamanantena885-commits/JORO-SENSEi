#!/usr/bin/env python3
"""Fampitahana nps: dikan-teny taloha vs vaovao ao amin'ny job iray (runner iray), mifandimby.

  python3 tools/benchcmp.py <cls_base> <cls_new> [--runs 5] [--depth 9] [--movetime 60]
Manoratra ny tabilao ao amin'ny $GITHUB_STEP_SUMMARY raha misy. Ny 'nodes' dia tokony hitovy raha
fanatsarana hafainganana fotsiny ny patch (tsy niova ny fikarohana).
"""
import argparse, os, re, statistics, subprocess

def run(cls, depth, mt):
    out = subprocess.run(["java", "-cp", cls, "mg.chess.offline.own.Bench", str(depth), str(mt)],
                         capture_output=True, text=True, check=True).stdout
    d = [m for m in re.finditer(r"BENCH_DEPTH pass=(\d+).*?nodes=(\d+) time=(\d+)ms nps=(\d+)", out)][-1]
    t = re.search(r"BENCH_TIME .*?avg_depth=([\d.]+) nodes=(\d+) nps=(\d+)", out)
    return dict(nodes=int(d.group(2)), nps_d=int(d.group(4)), depth_t=float(t.group(1)), nps_t=int(t.group(3)))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base"); ap.add_argument("new")
    ap.add_argument("--runs", type=int, default=5)
    ap.add_argument("--depth", type=int, default=9)
    ap.add_argument("--movetime", type=int, default=60)
    a = ap.parse_args()
    R = {"base": [], "new": []}
    for i in range(a.runs):                       # mifandimby: voasivana ny tabataba amin'ny runner
        for k, cls in (("base", a.base), ("new", a.new)) if i % 2 == 0 else (("new", a.new), ("base", a.base)):
            r = run(cls, a.depth, a.movetime); R[k].append(r)
            print(f"run {i+1} {k:4s} nodes={r['nodes']} nps_depth={r['nps_d']} nps_time={r['nps_t']} depth@{a.movetime}ms={r['depth_t']}", flush=True)
    med = lambda k, f: statistics.median(x[f] for x in R[k])
    rows = [("nodes (d%d)" % a.depth, "nodes", "{:.0f}"), ("nps depth raikitra", "nps_d", "{:.0f}"),
            ("nps fotoana raikitra (%dms)" % a.movetime, "nps_t", "{:.0f}"), ("depth salan-tsiasa", "depth_t", "{:.2f}")]
    lines = ["| refy | taloha | vaovao | vaovao/taloha |", "|---|---|---|---|"]
    for name, f, fmt in rows:
        b, n = med("base", f), med("new", f)
        lines.append(f"| {name} | {fmt.format(b)} | {fmt.format(n)} | x{n/b:.3f} |")
    same = {x["nodes"] for x in R["base"]} == {x["nodes"] for x in R["new"]}
    lines.append(f"\nNodes {'mitovy (tsy niova ny fikarohana)' if same else 'MIOVA (niova ny fikarohana: mila SPRT)'} · salanisa/median amin'ny {a.runs} run")
    txt = "\n".join(lines); print(txt)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        open(os.environ["GITHUB_STEP_SUMMARY"], "a").write("### JORO bench: taloha vs vaovao\n" + txt + "\n")

if __name__ == "__main__":
    main()
