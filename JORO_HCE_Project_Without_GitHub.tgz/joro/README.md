# JORO: motera manokana (HCE) nesorina tamin'ny app

Java pur (tsy misy Android/Kotlin), JDK 17+. `src/` = motera, `tools/` = fitaovana, `tests/` = fitsapana.

## Build
    ./build.sh      # -> joro.jar (UCI) sy build/cls

## Fampiasana  (C = mg.chess.offline.own)
    java -jar joro.jar                                    # UCI (cutechess-cli, lichess-bot...). Safidy: Eval2..Eval6, Elo (profile bot), Hash...
    java -cp build/cls $C.Bench 9 60 [Safidy=1 ...]       # nodes (famantarana ny search), nps, depth@60ms
    java -cp build/cls $C.Perft                           # tokony PASS (nodes=16989881)
    java -cp build/cls $C.SymTest [Eval6=1 ...]           # eval symmetry (mirror) tokony PASS
    java -cp build/cls $C.Match / SelfPlay                # fifaninanana / data Texel
    java -Dgroups=w5 -cp build/cls $C.Texel <out> <data>  # Texel (jereo workflows/texel.yml)

**Fototra bench (project-75):** `Bench 9 60` => nodes=**429554** (Eval5=1 default, Eval6=0). Miaraka amin'ny `Eval5=0` => 432893; `Eval6=1` => 470307. Raha miova ny nodes rehefa tsy nampiova search/eval intsony ianao, misy simba. Ny fanovana search dia mampiova ny nodes (mahazatra): ampitahao amin'ny SPRT.

## Rafitra
- `src/Search.java`: alpha-beta, TT, LMR, NMP, RFP/razor/futility, aspiration. Safidy search (`ProbCut`, `HistPrune`, `SeePrune`, `TtEval`... default 0) ao amin'ny `Params.java`.
- `src/Eval.java`: HCE; Eval2..Eval6 = vondrona toetra (`Params.EVALn`). Lanja voatombana ao amin'ny "Lanja voatombana" (`tools/apply_tuned.py`).
- `src/Params.java`: safidy UCI/SPSA/SPRT `reg(nom, default, min, max)`.
- `src/OwnBot.java`: fampiasana ao amin'ny app (profile Elo bot, `thinkFor`); `GambitBook`/`PgnBot`: bot toetra.
- `tools/*.py` + `workflows/*.yml`: SPRT, SPSA, Texel, calibrate vs Stockfish `UCI_Elo` (mila stockfish + python-chess). Ny lalana ao anatin'ny workflow dia natao ho an'ny repo taloha.
- `docs/OWN_ENGINE.md`: tantara project-60..75 sy valin'ny SPRT/Texel/calibrate rehetra.

## Valiny fototra (2026-11)
Hery feno ~2650-2690 ±40-60 (Stockfish UCI_Elo, 1500 ms). Eval5 default 1 (~+10 Elo). Eval6, ProbCut, HistPrune, SeePrune, TtEval: tsy misy tombony voaporofo (default 0).

## Fampiasana amin'ny app
Ny app dia mampiasa ny `src/*.java` mitovy (`app/src/main/java/mg/chess/offline/own/`). Rehefa vita ny fanovana: adikao any, ary jereo Bench/Perft aloha.

## GitHub Actions: SPRT (HCE-only)

Misy workflow vaovao ao amin'ny `.github/workflows/joro-sprt.yml`.

1. Apetraho ao amin'ny GitHub repository ny projet manontolo, ka eo amin'ny root ny `build.sh`, `src/`, `tools/` ary `.github/`.
2. Ataovy azo antoka fa misy branch `main` misy ny version fototra.
3. Ao amin'ny GitHub: **Actions → JORO HCE — SPRT → Run workflow**.
4. Safidio ny `base_ref` (matetika `main`) sy ny mode:
   - `quick`: hatramin'ny 100 games, 100 ms/move (screening fohy).
   - `standard`: hatramin'ny 400 games, 100 ms/move (test mahazatra).
   - `deep`: hatramin'ny 1200 games, 100 ms/move (test lalina; mety haharitra ora maromaro).
5. Jereo ny Summary sy ny artifact `joro-sprt-*` rehefa vita.

Ny workflow dia manao build ny base sy candidate, avy eo Perft, symmetry ary UCI sanity checks amin'ny candidate. Raha mandalo ireo dia manao match SPRT candidate-vs-base. Ny SPRT dia mampiasa H0=0 Elo, H1=+5 Elo, alpha=beta=0.05; `H1`, `H0` na `INCONCLUSIVE` no vokatra azo. Ny `H0` eto dia midika fa tsy nahazo porofo ampy hanohanana ny +5 Elo; tsy porofo mandeha ho azy hoe malemy kokoa ilay candidate. Tsy mitovy amin'ny absolute Elo rating izany: mila calibration amin'ny motera ivelany manana rating azo itokisana ny fanombanana 3000 Elo.

**Fanamarihana statistika:** `tools/sprt.py` amin'ity projet ity dia mampiasa approximate W/D/L-based LLR, fa tsy pentanomial likelihood model mahazatra amin'ny chess SPRT. Ampiasao ho regression gate fampitahana version izy aloha; aza raisina ho porofo farany amin'ny Elo marina raha tsy nohatsaraina sy nohamarinina ilay statistical model. Ny `quick` dia screening ihany, fa tsy ampy hanaporofoana fiovana kely toy ny +5 Elo.
