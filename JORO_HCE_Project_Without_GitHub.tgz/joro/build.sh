#!/usr/bin/env bash
# Build JORO (motera manokana): JDK 17+. Mivoaka: build/cls + joro.jar (UCI, Main-Class OwnUci)
set -e
cd "$(dirname "$0")"
rm -rf build && mkdir -p build/cls
if command -v javac >/dev/null; then JAVAC="javac"; JAR="jar"
else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; JAR="java -m jdk.jartool/sun.tools.jar.Main"; fi
$JAVAC -d build/cls src/*.java tools/*.java tests/*.java
printf 'Main-Class: mg.chess.offline.own.OwnUci\n' > build/manifest.txt
$JAR cfm joro.jar build/manifest.txt -C build/cls .
echo "OK: joro.jar (UCI) + build/cls"
