package mg.chess.offline.own;
public class SymTest {
    static String mirror(String fen) {
        String[] p = fen.split(" ");
        String[] rk = p[0].split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 7; i >= 0; i--) {
            for (char ch : rk[i].toCharArray()) sb.append(Character.isUpperCase(ch) ? Character.toLowerCase(ch) : Character.toUpperCase(ch));
            if (i > 0) sb.append('/');
        }
        String side = p[1].equals("w") ? "b" : "w";
        String cas = "";
        for (char ch : p[2].toCharArray()) cas += ch == '-' ? "-" : (Character.isUpperCase(ch) ? Character.toLowerCase(ch) : Character.toUpperCase(ch));
        String ep = p[3].equals("-") ? "-" : "" + p[3].charAt(0) + (char) ('1' + ('8' - p[3].charAt(1)));
        return sb + " " + side + " " + cas + " " + ep + " 0 1";
    }
    public static void main(String[] a) {
        for (String o : a) { String[] kv = o.split("="); Params.set(kv[0], Integer.parseInt(kv[1])); }
        String[] fens = {
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
            "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4",
            "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
            "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
            "r2q1rk1/pP1p2pp/Q4n2/bbp1p3/Np6/1B3NBn/pPPP1PPP/R3K2R b KQ - 0 1",
            "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
            "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
            "3r2k1/5ppp/8/2n5/4Pq2/2N2P2/5QPP/3R2K1 w - - 0 1",
            "6k1/5ppp/8/8/3n4/2P1r3/5PPP/3Q2K1 b - - 0 1",
            "r1b2rk1/pp2qppp/2n1pn2/3p4/1bPP4/2NBPN2/PP3PPP/R1BQ1RK1 w - - 0 9",
            "2r3k1/1b3ppp/p3p3/1p2P3/3NQ3/P1P5/1P3PPP/q4RK1 w - - 0 1",
            "8/8/4k3/3p4/3P4/4K3/8/8 w - - 0 1"};
        Eval e = new Eval(50, 50, 50, 50, 50);
        int bad = 0, nonzero = 0;
        for (String f : fens) {
            Pos p1 = new Pos(), p2 = new Pos();
            if (!p1.setFen(f) || !p2.setFen(mirror(f))) { System.out.println("FEN diso " + f); bad++; continue; }
            int v1 = e.evalRaw(p1), v2 = e.evalRaw(p2);
            if (v1 != v2) { bad++; System.out.println("TSY MITOVY " + v1 + " vs " + v2 + " :: " + f); }
            if (v1 != 0) nonzero++;
        }
        System.out.println("SYMMETRY " + (bad == 0 ? "PASS" : "FAIL") + " fens=" + fens.length + " nonzero=" + nonzero);
    }
}
