package mg.chess.offline.own;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.BooleanSupplier;

/**
 * Mamorona bot avy amin'ny lalao PGN amin'ny motera manokana (tsy mila Stockfish):
 *  1) BOOK = ny hetsika tena nataon'ny mpilalao tamin'ny lalao ROHY (opening favorite, araka ny matetika sy ny valiny);
 *  2) Elo = fanombanana avy amin'ny ACPL (fikarohana an'ny motera manokana), mitovy formula amin'ny Review.kt;
 *  3) famintinana (hetsika voalohany tiany, valiny amin'ny e4/d4...).
 * Ny toetra (a,s,d,q,t) dia kajiana ao amin'ny Personality.deriveStyle (Kotlin) ary ampiasain'ny Eval.
 * Java madio: tsy mampiasa Android na chesslib.
 */
public final class PgnBot {
    private PgnBot() {}

    public static final String START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    /** Hetsika (ply) voalohany voarakitra ao amin'ny book: 24 = 12 hetsika isaky ny loko. */
    public static final int BOOK_PLIES = 24;
    public static final int MAX_BOOK = 400;

    /** Lalao iray ho an'ny mpilalao: white = ny loko nilalaovany. score: 1 = nandresy, 0.5 = nul, 0 = resy, -1 = tsy fantatra. */
    public static final class Game {
        public final String startFen;
        public final List<String> uci;
        public final boolean white;
        public final int tagElo;      // 0 = tsy misy
        public final double score;
        public Game(String startFen, List<String> uci, boolean white, int tagElo, double score) {
            this.startFen = startFen == null ? START_FEN : startFen;
            this.uci = uci; this.white = white; this.tagElo = tagElo; this.score = score;
        }
    }

    public static final class Result {
        public int games;
        public int analysed;        // isan'ny hetsika nodinihina
        public double acpl;
        public double accuracy;     // 0..100
        public int rating;          // avy amin'ny ACPL (300..3200)
        public int elo;             // rating + tag Elo, boribory amin'ny 50
        public List<String> book = new ArrayList<String>();
        public List<String> summary = new ArrayList<String>();
    }

    public interface Progress { void on(float p); }

    // ---------------------------------------------------------------- book

    /** Fanalahidy: hash an'ny toerana tsy miankina amin'ny ep (FEN samihafa dia mety hanisy/tsy hanisy ep). */
    static long keyOf(Pos p) {
        long k = p.key;
        if (p.ep >= 0) k ^= Pos.ZE[p.ep & 7];
        return k;
    }

    /** Toerana mahazatra (tsy miankina amin'ny isan'ny hetsika ao amin'ny FEN). */
    static boolean isStart(String fen) {
        return fen != null && fen.trim().startsWith("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq");
    }

    private static String hex(long k) {
        String h = Long.toHexString(k);
        StringBuilder sb = new StringBuilder(16);
        for (int i = h.length(); i < 16; i++) sb.append('0');
        return sb.append(h).toString();
    }

    /** Entana: "<hash16>:<uci>:<isa>". Hetsika nataon'ny mpilalao ihany (araka ny lokony) ao anatin'ny BOOK_PLIES voalohany. */
    public static List<String> buildBook(List<Game> games) {
        Map<String, double[]> acc = new LinkedHashMap<String, double[]>();   // "hash:uci" -> {lanja, ply}
        for (Game g : games) {
            if (!isStart(g.startFen)) continue;                                // toerana namboarina: tsy ao amin'ny book
            Pos p = new Pos();
            p.startPos();
            int lim = Math.min(g.uci.size(), BOOK_PLIES);
            double w = g.score == 1.0 ? 1.5 : g.score == 0.5 ? 1.2 : 1.0;
            for (int i = 0; i < lim; i++) {
                String u = g.uci.get(i).toLowerCase();
                int mv = p.parseMove(u);
                if (mv == 0) break;
                boolean mine = (p.side == 0) == g.white;
                if (mine) {
                    String k = hex(keyOf(p)) + ":" + u;
                    double[] a = acc.get(k);
                    if (a == null) { a = new double[]{0, i}; acc.put(k, a); }
                    a[0] += w;
                }
                if (!p.make(mv)) break;
            }
        }
        List<Map.Entry<String, double[]>> es = new ArrayList<Map.Entry<String, double[]>>(acc.entrySet());
        Collections.sort(es, (x, y) -> {
            int c = Double.compare(y.getValue()[0], x.getValue()[0]);
            return c != 0 ? c : Double.compare(x.getValue()[1], y.getValue()[1]);
        });
        List<String> out = new ArrayList<String>();
        for (Map.Entry<String, double[]> e : es) {
            if (out.size() >= MAX_BOOK) break;
            out.add(e.getKey() + ":" + Math.max(1, (int) Math.round(e.getValue()[0] * 2)));
        }
        return out;
    }

    /** Endrika marina ho an'ny entana (fanamarinana fa tsy simba ilay pack nampidirina). */
    public static boolean validEntry(String e) {
        if (e == null || e.length() < 21 || e.length() > 30) return false;
        for (int i = 0; i < 16; i++) if (Character.digit(e.charAt(i), 16) < 0) return false;
        String[] t = e.split(":");
        if (t.length != 3 || t[0].length() != 16) return false;
        String m = t[1];
        if (m.length() != 4 && m.length() != 5) return false;
        if (m.charAt(0) < 'a' || m.charAt(0) > 'h' || m.charAt(1) < '1' || m.charAt(1) > '8') return false;
        if (m.charAt(2) < 'a' || m.charAt(2) > 'h' || m.charAt(3) < '1' || m.charAt(3) > '8') return false;
        if (m.length() == 5 && "qrbn".indexOf(m.charAt(4)) < 0) return false;
        try { int n = Integer.parseInt(t[2]); return n >= 1 && n <= 100000; } catch (NumberFormatException ex) { return false; }
    }

    /** Hetsika avy amin'ny book (null raha tsy ao: avy eo ny motera no misaina). Safidy araka ny isa (^1.5 = tia ny favorite). */
    public static String bookMove(String fen, List<String> book, Random rnd) {
        if (book == null || book.isEmpty()) return null;
        Pos p = new Pos();
        if (!p.setFen(fen)) return null;
        String prefix = hex(keyOf(p)) + ":";
        List<String> mv = new ArrayList<String>();
        List<Double> wt = new ArrayList<Double>();
        double tot = 0;
        for (String e : book) {
            if (!e.startsWith(prefix)) continue;
            String[] t = e.split(":");
            if (t.length != 3) continue;
            int cnt;
            try { cnt = Integer.parseInt(t[2]); } catch (NumberFormatException ex) { continue; }
            if (p.parseMove(t[1]) == 0) continue;                              // tsy legal (hash mifandona): afaka
            double w = Math.pow(Math.max(1, cnt), 1.5);
            mv.add(t[1]); wt.add(w); tot += w;
        }
        if (mv.isEmpty()) return null;
        double r = rnd.nextDouble() * tot;
        for (int i = 0; i < mv.size(); i++) { r -= wt.get(i); if (r <= 0) return mv.get(i); }
        return mv.get(mv.size() - 1);
    }

    // ---------------------------------------------------------------- Elo (ACPL)

    private static double winPct(int cp) { return 100.0 / (1.0 + Math.exp(-0.00368208 * cp)); }
    private static int clamp(int v, int lim) { return Math.max(-lim, Math.min(lim, v)); }

    /**
     * Mandinika hetsika nataon'ny mpilalao (farafahakeliny: ny ply 8 aorian'ny fiandohana, fa ny opening dia teoria)
     * amin'ny fikarohana an'ny motera manokana. Mamerina Result feno (book + Elo + famintinana).
     */
    public static Result build(List<Game> games, int maxMoves, int depth, int msPerSearch,
                               BooleanSupplier cancelled, Progress progress) {
        Result r = new Result();
        r.games = games.size();
        r.book = buildBook(games);

        // hetsika hodinihina: ply (isa ao amin'ny lalao) voafantina mitovy elanelana
        List<int[]> cand = new ArrayList<int[]>();                              // {lalao, ply}
        for (int gi = 0; gi < games.size(); gi++) {
            Game g = games.get(gi);
            int from = isStart(g.startFen) ? 8 : 0;
            int lim = Math.min(g.uci.size(), 90);
            for (int i = from; i < lim; i++) if (((i % 2) == 0) == g.white) cand.add(new int[]{gi, i});
        }
        boolean[][] pick = new boolean[games.size()][];
        for (int gi = 0; gi < games.size(); gi++) pick[gi] = new boolean[Math.min(games.get(gi).uci.size(), 90)];
        int chosen = 0;
        if (cand.size() <= maxMoves) {
            for (int[] c : cand) { pick[c[0]][c[1]] = true; chosen++; }
        } else {
            double step = cand.size() / (double) maxMoves;
            for (int k = 0; k < maxMoves; k++) { int[] c = cand.get((int) (k * step)); pick[c[0]][c[1]] = true; chosen++; }
        }

        double lossSum = 0, accSum = 0; int n = 0, done = 0;
        Search s = new Search(new Eval(50, 50, 50, 50, 50));
        for (int gi = 0; gi < games.size() && chosen > 0; gi++) {
            Game g = games.get(gi);
            boolean any = false;
            for (boolean b : pick[gi]) if (b) { any = true; break; }
            if (!any) continue;
            if (cancelled != null && cancelled.getAsBoolean()) break;
            s.clear();
            if (!s.pos.setFen(g.startFen)) continue;
            for (int i = 0; i < pick[gi].length; i++) {
                int mv = s.pos.parseMove(g.uci.get(i).toLowerCase());
                if (mv == 0) break;
                if (pick[gi][i]) {
                    if (cancelled != null && cancelled.getAsBoolean()) break;
                    Search.Result best = s.think(depth, msPerSearch);
                    int bs = clamp(best.score, 1000);
                    int ps;
                    if (best.move == mv) ps = bs;
                    else {
                        s.pos.make(mv);
                        Search.Result opp = s.think(Math.max(1, depth - 1), msPerSearch);
                        if (opp.move == 0) ps = s.pos.inCheck() ? 1000 : 0;     // mat (nandresy) na pat
                        else ps = clamp(-opp.score, 1000);
                        s.pos.unmake();
                    }
                    int loss = Math.max(0, Math.min(500, bs - ps));
                    lossSum += loss;
                    double wl = Math.max(0, winPct(bs) - winPct(ps));
                    accSum += Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * wl) - 3.1669));
                    n++; done++;
                    if (progress != null) progress.on(done / (float) Math.max(1, chosen));
                }
                if (!s.pos.make(mv)) break;
            }
        }
        r.analysed = n;
        if (n > 0) {
            r.acpl = lossSum / n;
            r.accuracy = accSum / n;
            r.rating = (int) Math.max(300, Math.min(3200, Math.round(3100 * Math.exp(-0.0086 * r.acpl))));
        } else {
            r.rating = 1200; r.acpl = 0; r.accuracy = 0;
        }
        double tagSum = 0; int tagN = 0;
        for (Game g : games) if (g.tagElo > 0) { tagSum += g.tagElo; tagN++; }
        int est = tagN > 0 ? (int) Math.round((r.rating + tagSum / tagN) / 2.0) : r.rating;
        r.elo = Math.max(100, Math.min(3200, (int) Math.round(est / 50.0) * 50));
        r.summary = summarize(games);
        return r;
    }

    // ---------------------------------------------------------------- famintinana ("opening favorite")

    private static String pct(int a, int tot) { return Math.round(100.0 * a / tot) + "%"; }

    /** Andalana fohy: valiny/hetsika voalohany tiana indrindra (Fotsy: hetsika 1; Mainty: valiny amin'ny e4 / d4). */
    static List<String> summarize(List<Game> games) {
        List<String> out = new ArrayList<String>();
        int w = 0, d = 0, l = 0;
        for (Game g : games) { if (g.score == 1.0) w++; else if (g.score == 0.5) d++; else if (g.score == 0.0) l++; }
        if (w + d + l > 0) out.add("Valiny: fandresena " + w + " / nul " + d + " / resy " + l);
        Map<String, Integer> first = new HashMap<String, Integer>();
        Map<String, Integer> vsE4 = new HashMap<String, Integer>();
        Map<String, Integer> vsD4 = new HashMap<String, Integer>();
        int nw = 0, ne4 = 0, nd4 = 0;
        for (Game g : games) {
            if (!isStart(g.startFen) || g.uci.isEmpty()) continue;
            if (g.white) { nw++; first.merge(g.uci.get(0).toLowerCase(), 1, Integer::sum); }
            else if (g.uci.size() >= 2) {
                String f = g.uci.get(0).toLowerCase(), a = g.uci.get(1).toLowerCase();
                if (f.equals("e2e4")) { ne4++; vsE4.merge(a, 1, Integer::sum); }
                else if (f.equals("d2d4")) { nd4++; vsD4.merge(a, 1, Integer::sum); }
            }
        }
        String t = top(first, nw); if (t != null) out.add("Fotsy: " + t);
        t = top(vsE4, ne4); if (t != null) out.add("Mainty vs e4: " + t);
        t = top(vsD4, nd4); if (t != null) out.add("Mainty vs d4: " + t);
        return out;
    }

    private static String top(Map<String, Integer> m, int tot) {
        if (tot <= 0 || m.isEmpty()) return null;
        String bk = null; int bv = 0;
        for (Map.Entry<String, Integer> e : m.entrySet())
            if (e.getValue() > bv || (e.getValue() == bv && e.getKey().compareTo(bk) < 0)) { bk = e.getKey(); bv = e.getValue(); }
        return bk + " (" + pct(bv, tot) + ", " + tot + " lalao)";
    }
}
