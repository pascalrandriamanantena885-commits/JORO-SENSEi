package mg.chess.offline.own;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Book gambit an'i JORO (fomba manokana: sacrifice / gambit). Tsy miankina amin'ny Stockfish.
 * Isaky ny andalana: gambiteer ('W' = JORO Fotsy, 'B' = JORO Mainty) + hetsika UCI avy amin'ny fiandohana.
 * Raha tsy mifanaraka ny tantara (ny mpifanandrina niala) dia miverina null ary ny fikarohana no mandray.
 */
public final class GambitBook {
    private GambitBook() {}

    static final String[] LINES = {
        // ---- JORO Fotsy ----
        "W e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 h2h4 g5g4 f3e5",                    // King's Gambit (Kieseritzky)
        "W e2e4 e7e5 f2f4 f8c5 g1f3 d7d6 c2c3",                              // King's Gambit (Classical)
        "W e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4",          // Evans Gambit
        "W e2e4 e7e5 d2d4 e5d4 c2c3 d4c3 f1c4 c3b2 c1b2",                    // Danish Gambit
        "W e2e4 c7c5 d2d4 c5d4 c2c3 d4c3 b1c3 b8c6 g1f3 d7d6 f1c4",          // Smith-Morra Gambit
        "W e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f1c4 f8c5 e1g1 d7d6 c2c3",          // Scotch Gambit
        "W e2e4 e7e5 b1c3 g8f6 f2f4 d7d5 f4e5 f6e4 g1f3",                    // Vienna Gambit
        "W d2d4 d7d5 e2e4 d5e4 b1c3 g8f6 f2f3 e4f3 g1f3",                    // Blackmar-Diemer Gambit
        // ---- JORO Mainty ----
        "B d2d4 g8f6 c2c4 c7c5 d4d5 b7b5 c4b5 a7a6 b5a6 c8a6",               // Benko Gambit
        "B d2d4 d7d5 c2c4 e7e5 d4e5 d5d4 g1f3 b8c6 g2g3",                    // Albin Counter-Gambit
        "B d2d4 g8f6 c2c4 e7e5 d4e5 f6g4 g1f3 b8c6 b1c3",                    // Budapest Gambit
        "B e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6",     // Two Knights (5...Na5)
    };

    private static final class Line { final char side; final String[] mv; Line(char s, String[] m) { side = s; mv = m; } }
    private static final List<Line> PARSED = new ArrayList<>();
    static {
        for (String l : LINES) {
            String[] t = l.split(" ");
            String[] m = new String[t.length - 1];
            System.arraycopy(t, 1, m, 0, m.length);
            PARSED.add(new Line(t[0].charAt(0), m));
        }
    }

    /** Hetsika UCI manaraka araka ny tantara (hatramin'ny fiandohana), na null raha tsy misy andalana mifanaraka. */
    public static String pick(List<String> hist, Random rnd) {
        if (hist == null) return null;
        final int n = hist.size();
        final char me = (n & 1) == 0 ? 'W' : 'B';
        List<String> cand = new ArrayList<>();
        outer:
        for (Line ln : PARSED) {
            if (ln.side != me || ln.mv.length <= n) continue;
            for (int i = 0; i < n; i++) if (!ln.mv[i].equals(hist.get(i))) continue outer;
            cand.add(ln.mv[n]);
        }
        if (cand.isEmpty()) return null;
        return cand.get(rnd.nextInt(cand.size()));
    }

    /** True raha ny toerana {@code target} dia azo avy amin'ny fiandohana amin'ny {@code hist} (tsy misy FEN manokana). */
    public static boolean fromStart(Pos target, List<String> hist) {
        Pos q = new Pos();
        q.startPos();
        for (String u : hist) {
            int mv = q.parseMove(u);
            if (mv == 0 || !q.make(mv)) return false;
        }
        return q.key == target.key && q.side == target.side;
    }

    /** Fanamarinana ho an'ny test: ny andalana rehetra dia marina (legal) avy amin'ny fiandohana. */
    public static boolean allLegal() {
        for (Line ln : PARSED) {
            Pos q = new Pos();
            q.startPos();
            for (String u : ln.mv) {
                int mv = q.parseMove(u);
                if (mv == 0 || !q.make(mv)) return false;
            }
        }
        return true;
    }
}
