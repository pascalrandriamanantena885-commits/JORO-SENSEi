package mg.chess.offline.own;

import java.util.Random;

/** Fikarohana: iterative deepening + PVS + TT + null move + LMR + quiescence. */
public final class Search {
    static final int INF = 32000, MATE = 30000, MATE_BOUND = MATE - 200;
    static final int MAXPLY = 96;
    static final int[][] LMR = new int[64][64];

    static void rebuildLmr() {
        final double base = Params.LMR_BASE.val / 100.0, div = Params.LMR_DIV.val / 100.0;
        for (int d = 1; d < 64; d++) for (int m = 1; m < 64; m++)
            LMR[d][m] = (int) (base + Math.log(d) * Math.log(m) / div);
    }

    static { rebuildLmr(); }

    public final Pos pos = new Pos();
    Eval ev;
    private int ttMask = (1 << 19) - 1;
    private long[] tKey = new long[1 << 19];
    private int[] tMove = new int[1 << 19];
    private short[] tScore = new short[1 << 19];
    private byte[] tDepth = new byte[1 << 19];
    private byte[] tFlag = new byte[1 << 19]; // 1=exact 2=lower 3=upper
    private final int[][] killers = new int[MAXPLY + 2][2];
    private final int[][][] hist = new int[2][128][128];
    private final int[][] cmv = new int[128][128];          // countermove[prevFrom][prevTo]
    private final int[] moveAt = new int[MAXPLY + 2];
    private final int[] evalAt = new int[MAXPLY + 2];
    private final boolean[] cutAt = new boolean[MAXPLY + 2];     // node miandry fail-high (LmrCut)
    private final int[][] quietsTried = new int[MAXPLY + 2][64];
    private final int[] excl = new int[MAXPLY + 2];
    private final int[] pieceAt = new int[MAXPLY + 2];           // karazana piece nihetsika tamin'ny ply
    private final int[][] capsTried = new int[MAXPLY + 2][32];
    private final int[] capHist = new int[8 * 1024];             // [attacker][to][victim]
    private int[] contHist;                                      // [prevPt][prevTo][pt][to] (lazy, 4MB)
    private final int[][] saveMs = new int[MAXPLY + 2][256];
    private final int[][] saveSs = new int[MAXPLY + 2][256];
    private final int[] sb = new int[128];
    private final int[] gain = new int[40];
    static final int[] SEEV = {0, 100, 320, 330, 500, 900, 20000};
    private final int[][] mv = new int[MAXPLY + 2][256];
    private final int[][] sc = new int[MAXPLY + 2][256];

    long nodes;
    private long deadline;
    private boolean stop;
    private int rootMove, rootScore;
    int lastDepth;
    private int contempt;                                    // cp (Contempt): ialana ny draw ho an'ny mpilalao root
    private int drawVal(int ply) { return (ply & 1) == 0 ? -contempt : contempt; }

    public Search(Eval ev) { this.ev = ev; }

    /** Ovay ny habetsaky ny TT (2^bits entana). Fafana ny votoaty. */
    public void setHash(int bits) {
        bits = Math.max(16, Math.min(24, bits));
        ttMask = (1 << bits) - 1;
        tKey = new long[1 << bits]; tMove = new int[1 << bits]; tScore = new short[1 << bits];
        tDepth = new byte[1 << bits]; tFlag = new byte[1 << bits];
    }

    public void clear() {
        java.util.Arrays.fill(tKey, 0L);
        for (int[] k : killers) { k[0] = 0; k[1] = 0; }
        for (int[][] a : hist) for (int[] b : a) java.util.Arrays.fill(b, 0);
        for (int[] c : cmv) java.util.Arrays.fill(c, 0);
        java.util.Arrays.fill(capHist, 0);
        if (contHist != null) java.util.Arrays.fill(contHist, 0);
    }

    /** Rook gambit: aorian'ny hetsika m (sacrifice SEE ratsy), misy rook contact/line misokatra mankany amin'ny mpanjaka ve? (SEE no mande voalohany, ity no manamarina) */
    private boolean rookGambit(int m) {
        final int me = pos.side;
        if (!pos.make(m)) return false;
        boolean r = Eval.rookContact(pos, me);
        pos.unmake();
        return r;
    }

    private static int kdist(int a, int b) { return Math.max(Math.abs((a & 7) - (b & 7)), Math.abs((a >> 4) - (b >> 4))); }

    private int capIdx(int m) {
        int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
        int att = pos.b[Pos.from(m)] & 7;
        return (att << 10) | (Pos.to(m) << 3) | victim;
    }

    // ---------- SEE (static exchange evaluation) ----------
    private int leastAttacker(int to, int side) {
        final int[] b = sb;
        final int off = side << 3;
        if (side == 0) {
            int s1 = to - 15, s2 = to - 17;
            if ((s1 & 0x88) == 0 && b[s1] == Pos.P) return s1;
            if ((s2 & 0x88) == 0 && b[s2] == Pos.P) return s2;
        } else {
            int s1 = to + 15, s2 = to + 17;
            if ((s1 & 0x88) == 0 && b[s1] == (Pos.P | 8)) return s1;
            if ((s2 & 0x88) == 0 && b[s2] == (Pos.P | 8)) return s2;
        }
        for (int d : Pos.KN) { int s = to + d; if ((s & 0x88) == 0 && b[s] == (Pos.N | off)) return s; }
        for (int d : Pos.BD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.B | off)) return s; break; } s += d; }
        }
        for (int d : Pos.RD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.R | off)) return s; break; } s += d; }
        }
        for (int d : Pos.BD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.Q | off)) return s; break; } s += d; }
        }
        for (int d : Pos.RD) {
            int s = to + d;
            while ((s & 0x88) == 0) { int p = b[s]; if (p != 0) { if (p == (Pos.Q | off)) return s; break; } s += d; }
        }
        for (int d : Pos.KG) { int s = to + d; if ((s & 0x88) == 0 && b[s] == (Pos.K | off)) return s; }
        return -1;
    }

    /** SEE ho an'ny fakana m (alohan'ny make). Miverina cp araka ny mpilalao mihetsika. */
    int see(int m) {
        final int from = Pos.from(m), to = Pos.to(m);
        System.arraycopy(pos.b, 0, sb, 0, 128);
        final int us = pos.side;
        final boolean ep = (Pos.flag(m) & Pos.F_EP) != 0;
        int victim = ep ? Pos.P : (sb[to] & 7);
        int cur = sb[from] & 7;
        if (ep) sb[to + (us == 0 ? -16 : 16)] = 0;
        int d = 0;
        gain[0] = SEEV[victim];
        if (Pos.promo(m) != 0) { gain[0] += SEEV[Pos.promo(m)] - 100; cur = Pos.promo(m); }
        sb[from] = 0;
        sb[to] = cur | (us << 3);
        int side = us;
        boolean pruned = false;
        while (true) {
            side ^= 1;
            int sq = leastAttacker(to, side);
            if (sq < 0) break;
            d++;
            if (d >= 38) { pruned = true; break; }
            gain[d] = SEEV[cur] - gain[d - 1];
            if (Math.max(-gain[d - 1], gain[d]) < 0) { pruned = true; break; }
            cur = sb[sq] & 7;
            sb[sq] = 0;
        }
        if (pruned) d--;
        while (d > 0) { gain[d - 1] = -Math.max(-gain[d - 1], gain[d]); d--; }
        return gain[0];
    }

    private static int gravity(int h, int bonus) {
        return h + bonus - h * Math.abs(bonus) / 16384;
    }

    public long nodeLimit = 0;
    private void checkTime() {
        if (System.nanoTime() > deadline || (nodeLimit > 0 && nodes > nodeLimit)) stop = true;
    }

    private static int scoreToTT(int s, int ply) { return s >= MATE_BOUND ? s + ply : s <= -MATE_BOUND ? s - ply : s; }
    private static int scoreFromTT(int s, int ply) { return s >= MATE_BOUND ? s - ply : s <= -MATE_BOUND ? s + ply : s; }

    private int qsearch(int alpha, int beta, int ply) {
        if ((++nodes & 2047) == 0) checkTime();
        if (stop) return 0;
        final boolean inCheck = pos.inCheck();
        if (ply >= MAXPLY) return ev.eval(pos);
        if (beta - alpha == 1) {
            int qi = (int) (pos.key & ttMask);
            if (tKey[qi] == pos.key) {
                int ts = scoreFromTT(tScore[qi], ply), fl = tFlag[qi];
                if (fl == 1 || (fl == 2 && ts >= beta) || (fl == 3 && ts <= alpha)) return ts;
            }
        }
        final int qa0 = alpha;
        int stand = -INF;
        if (!inCheck) {
            stand = ev.eval(pos);
            if (stand >= beta) return stand;
            if (stand > alpha) alpha = stand;
        }
        int[] ms = mv[ply], ss = sc[ply];
        int n = inCheck ? pos.genAll(ms) : pos.gen(ms, true);
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
            int att = pos.b[Pos.from(m)] & 7;
            ss[i] = victim * 16 - att + (Pos.promo(m) != 0 ? 200 : 0);
        }
        int legal = 0, best = stand;
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (ss[j] > ss[bi]) bi = j;
            if (bi != i) { int t = ms[i]; ms[i] = ms[bi]; ms[bi] = t; t = ss[i]; ss[i] = ss[bi]; ss[bi] = t; }
            int m = ms[i];
            if (!inCheck && Pos.promo(m) == 0) {
                int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
                if (stand + Eval.V_MG[victim] + 200 < alpha) continue; // delta pruning
                int att = pos.b[Pos.from(m)] & 7;
                if (SEEV[victim] < SEEV[att] && see(m) < 0) continue;   // fakana very
            }
            if (!pos.make(m)) continue;
            legal++;
            int score = -qsearch(-beta, -alpha, ply + 1);
            pos.unmake();
            if (stop) return 0;
            if (score > best) {
                best = score;
                if (score > alpha) {
                    alpha = score;
                    if (score >= beta) { qsStore(ply, score, 2); return score; }
                }
            }
        }
        if (inCheck && legal == 0) return -MATE + ply;
        qsStore(ply, best, best > qa0 ? 1 : 3);
        return best;
    }

    private void qsStore(int ply, int score, int flag) {
        if (Params.QS_TT.val == 0 || stop || Math.abs(score) >= MATE_BOUND) return;
        final int qi = (int) (pos.key & ttMask);
        if (tKey[qi] == pos.key && tDepth[qi] > 0) return;          // aza soloina ny fidirana lalina kokoa
        if (tKey[qi] != pos.key) tMove[qi] = 0;
        tKey[qi] = pos.key; tDepth[qi] = 0; tScore[qi] = (short) score; tFlag[qi] = (byte) flag;
    }

    private int search(int alpha, int beta, int depth, int ply, boolean nullOk) {
        if ((++nodes & 2047) == 0) checkTime();
        if (stop) return 0;
        final boolean pv = beta - alpha > 1;
        final boolean root = ply == 0;
        if (!root) {
            if (pos.half >= 100 || pos.repeated()) return contempt == 0 ? 0 : drawVal(ply);
            alpha = Math.max(alpha, -MATE + ply);
            beta = Math.min(beta, MATE - ply - 1);
            if (alpha >= beta) return alpha;
        }
        final boolean inCheck = pos.inCheck();
        if (inCheck && ply < MAXPLY - 8) depth++;
        if (depth <= 0) return qsearch(alpha, beta, ply);
        if (ply >= MAXPLY - 2) return ev.eval(pos);

        final int ex = excl[ply];
        final int idx = (int) (pos.key & ttMask);
        int ttMove = 0;
        if (tKey[idx] == pos.key) {
            ttMove = tMove[idx];
            if (ex == 0 && !pv && !root && tDepth[idx] >= depth) {
                int ts = scoreFromTT(tScore[idx], ply);
                int fl = tFlag[idx];
                if (fl == 1 || (fl == 2 && ts >= beta) || (fl == 3 && ts <= alpha)) return ts;
            }
        }
        final int staticEval = inCheck ? -INF : ev.eval(pos);
        evalAt[ply] = staticEval;
        int pe = staticEval;
        if (Params.TT_EVAL.val != 0 && !inCheck && ex == 0 && tKey[idx] == pos.key) {
            final int ts = scoreFromTT(tScore[idx], ply), fl = tFlag[idx];
            if (Math.abs(ts) < MATE_BOUND && (fl == 1 || (fl == 2 && ts > staticEval) || (fl == 3 && ts < staticEval))) pe = ts;
        }
        final int pruneEval = pe;
        final boolean improving = !inCheck && ply >= 2 && evalAt[ply - 2] != -INF && staticEval > evalAt[ply - 2];
        if (!pv && !inCheck && !root) {
            // reverse futility
            final int rfp = improving ? Params.RFP_MARGIN_IMP.val : Params.RFP_MARGIN.val;
            if (depth <= 7 && pruneEval - rfp * depth >= beta && Math.abs(beta) < MATE_BOUND)
                return pruneEval - rfp * depth;
            // razoring
            if (depth <= 2 && staticEval + Params.RAZOR_MARGIN.val * depth < alpha) {
                int v = qsearch(alpha, beta, ply);
                if (v <= alpha) return v;
            }
            // null move
            if (ex == 0 && nullOk && depth >= 3 && pruneEval >= beta && pos.hasNonPawn(pos.side)) {
                int r = Params.NMP_BASE.val + depth / 4 + Math.min(2, (pruneEval - beta) / 200);
                moveAt[ply] = 0;
                pos.makeNull();
                cutAt[ply + 1] = !cutAt[ply];
                int s = -search(-beta, -beta + 1, depth - 1 - r, ply + 1, false);
                pos.unmakeNull();
                if (stop) return 0;
                if (s >= beta) {
                    if (Params.NMP_VERIFY.val != 0 && depth >= 12 && Math.abs(beta) < MATE_BOUND) {
                        // fanamarinana: fikarohana fohy tsy misy null move
                        int v = search(beta - 1, beta, depth - 1 - r, ply, false);
                        if (stop) return 0;
                        if (v >= beta) return s >= MATE_BOUND ? beta : s;
                    } else return s >= MATE_BOUND ? beta : s;
                }
            }
            // ProbCut: capture tsara mahatratra beta+margin amin'ny qsearch dia mety hahatratra amin'ny fikarohana fohy
            if (Params.PROBCUT.val != 0 && ex == 0 && depth >= 5 && Math.abs(beta) < MATE_BOUND) {
                final int pb = beta + Params.PROBCUT_MARGIN.val;
                final boolean skip = tKey[idx] == pos.key && tDepth[idx] >= depth - 3
                        && (tFlag[idx] == 1 || tFlag[idx] == 3) && scoreFromTT(tScore[idx], ply) < pb;
                if (!skip) {
                    final int[] pm = mv[ply], ps = sc[ply];
                    final int pn = pos.gen(pm, true);
                    for (int i = 0; i < pn; i++) {
                        int m = pm[i];
                        int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
                        ps[i] = (Pos.flag(m) & Pos.F_CAP) != 0 ? victim * 16 - (pos.b[Pos.from(m)] & 7) : -1000;
                    }
                    for (int i = 0; i < pn; i++) {
                        int bi = i;
                        for (int j = i + 1; j < pn; j++) if (ps[j] > ps[bi]) bi = j;
                        if (bi != i) { int t = pm[i]; pm[i] = pm[bi]; pm[bi] = t; t = ps[i]; ps[i] = ps[bi]; ps[bi] = t; }
                        if (ps[i] == -1000) break;               // tsy misy fakana intsony
                        int m = pm[i];
                        if (see(m) < pb - staticEval) continue;
                        final int pt = pos.b[Pos.from(m)] & 7;
                        if (!pos.make(m)) continue;
                        moveAt[ply] = m; pieceAt[ply] = pt;
                        int v = -qsearch(-pb, -pb + 1, ply + 1);
                        if (v >= pb && !stop) v = -search(-pb, -pb + 1, depth - 4, ply + 1, true);
                        pos.unmake();
                        if (stop) return 0;
                        if (v >= pb) {
                            tKey[idx] = pos.key; tMove[idx] = m; tDepth[idx] = (byte) Math.min(depth - 3, 100);
                            tScore[idx] = (short) scoreToTT(v, ply); tFlag[idx] = 2;
                            return v;
                        }
                    }
                }
            }
        }
        // internal iterative deepening
        if (Params.IIR.val != 0) {
            if (ex == 0 && ttMove == 0 && depth >= 4 && !root && (pv || staticEval + 100 >= beta)) depth--;
        } else if (ex == 0 && ttMove == 0 && depth >= 5 && !root && (pv || staticEval + 100 >= beta)) {
            search(alpha, beta, depth - 2, ply, false);
            if (stop) return 0;
            if (tKey[idx] == pos.key) ttMove = tMove[idx];
        }

        int[] ms = mv[ply], ss = sc[ply];
        int n = pos.genAll(ms);
        final int side = pos.side;
        final int prevMove = ply > 0 ? moveAt[ply - 1] : 0;
        final int counter = prevMove != 0 ? cmv[Pos.from(prevMove)][Pos.to(prevMove)] : 0;
        final boolean ttCap = ttMove != 0 && (Pos.flag(ttMove) & Pos.F_CAP) != 0;
        final boolean useCapH = Params.CAPT_HIST.val != 0;
        final boolean hunt = Params.JORO_HUNT.val != 0;
        final boolean rookG = Params.JORO_ROOK.val != 0;
        if (Params.CONT_HIST.val != 0 && contHist == null) contHist = new int[1 << 20];
        final int cb = (Params.CONT_HIST.val != 0 && prevMove != 0) ? (((pieceAt[ply - 1] << 7) | Pos.to(prevMove)) << 10) : -1;
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            int s;
            if (m == ttMove) s = 10_000_000;
            else if ((Pos.flag(m) & Pos.F_CAP) != 0) {
                int victim = (Pos.flag(m) & Pos.F_EP) != 0 ? Pos.P : (pos.b[Pos.to(m)] & 7);
                int att = pos.b[Pos.from(m)] & 7;
                int mvv = victim * 16 - att + (Pos.promo(m) == Pos.Q ? 100 : 0);
                final int mv2 = useCapH ? mvv * 64 + capHist[capIdx(m)] / 16 : mvv;
                if (SEEV[victim] >= SEEV[att]) s = 2_000_000 + mv2;
                else s = see(m) >= 0 ? 2_000_000 + mv2 : -2_000_000 + mv2;
            } else if (Pos.promo(m) != 0) s = Pos.promo(m) == Pos.Q ? 1_900_000 : -3_000_000;
            else if (m == killers[ply][0]) s = 1_000_000;
            else if (m == killers[ply][1]) s = 900_000;
            else if (m == counter) s = 800_000;
            else {
                s = hist[side][Pos.from(m)][Pos.to(m)];
                if (cb >= 0) s += contHist[cb + (((pos.b[Pos.from(m)] & 7) << 7) | Pos.to(m))];
            }
            ss[i] = s;
        }
        int best = -INF, bestMove = 0, legal = 0, nq = 0, nc = 0;
        final int origAlpha = alpha;
        final int[] tried = quietsTried[ply];
        for (int i = 0; i < n; i++) {
            int bi = i;
            for (int j = i + 1; j < n; j++) if (ss[j] > ss[bi]) bi = j;
            if (bi != i) { int t = ms[i]; ms[i] = ms[bi]; ms[bi] = t; t = ss[i]; ss[i] = ss[bi]; ss[bi] = t; }
            int m = ms[i];
            if (m == ex) continue;
            final boolean quiet = (Pos.flag(m) & Pos.F_CAP) == 0 && Pos.promo(m) == 0;
            final int hs = quiet ? hist[side][Pos.from(m)][Pos.to(m)]
                    + (cb >= 0 ? contHist[cb + (((pos.b[Pos.from(m)] & 7) << 7) | Pos.to(m))] : 0) : 0;
            final boolean badCap = !quiet && ss[i] < -1_000_000 && ss[i] > -2_500_000;
            final boolean huntMove = hunt && kdist(Pos.to(m), pos.ksq[side ^ 1]) <= 2;   // JORO: hetsika akaikin'ny mpanjaka mpifanandrina
            if (!root && !pv && !inCheck && legal > 0 && best > -MATE_BOUND) {
                if (badCap && depth <= 5 && ss[i] != 10_000_000 && !huntMove && !(rookG && rookGambit(m))) continue; // fakana very amin'ny depth fohy
                if (quiet && !huntMove) {
                    if (Params.HIST_PRUNE.val != 0 && depth <= 4 && hs < -Params.HIST_PRUNE_MUL.val * depth) continue;
                    if (Params.SEE_PRUNE.val != 0 && depth <= 6 && see(m) < -Params.SEE_QUIET.val * depth) continue;
                    if (depth <= 6 && legal > (improving ? 5 : 3) + depth * depth) continue;     // late move pruning
                    if (depth <= 6 && pruneEval + Params.FUT_BASE.val + Params.FUT_MUL.val * depth <= alpha && hs < 4000) continue; // futility
                }
            }
            int ext = 0;
            if (m == ttMove && ex == 0 && !root && depth >= 8 && tKey[idx] == pos.key && tDepth[idx] >= depth - 3
                    && (tFlag[idx] == 2 || tFlag[idx] == 1) && Math.abs(scoreFromTT(tScore[idx], ply)) < MATE_BOUND) {
                final int ttS = scoreFromTT(tScore[idx], ply);
                int sbeta = ttS - 2 * depth;
                System.arraycopy(ms, 0, saveMs[ply], 0, n); System.arraycopy(ss, 0, saveSs[ply], 0, n);
                excl[ply] = m;
                int v = search(sbeta - 1, sbeta, (depth - 1) / 2, ply, false);
                excl[ply] = 0;
                System.arraycopy(saveMs[ply], 0, ms, 0, n); System.arraycopy(saveSs[ply], 0, ss, 0, n);
                if (stop) return 0;
                if (v < sbeta) { ext = 1; if (Params.SING2.val != 0 && !pv && v < sbeta - 25) ext = 2; }
                else if (sbeta >= beta) return sbeta;
                else if (Params.SING2.val != 0 && ttS >= beta) ext = -1;
            }
            final int movedPt = pos.b[Pos.from(m)] & 7;
            if (!pos.make(m)) continue;
            legal++;
            moveAt[ply] = m; pieceAt[ply] = movedPt;
            final boolean givesCheck = pos.inCheck();
            // JORO: extension ho an'ny sacrifice / check akaikin'ny mpanjaka mpifanandrina (voafetra: depth >= 4, ply <= 24)
            final int hext = (ext == 0 && depth >= 5 && ply <= 20 && badCap && (huntMove || (rookG && Eval.rookContact(pos, side)))) ? 1 : 0;
            final int d1 = depth - 1 + hext;
            int score;
            if (legal == 1) {
                cutAt[ply + 1] = pv ? false : !cutAt[ply];
                score = -search(-beta, -alpha, depth - 1 + ext + hext, ply + 1, true);
            } else {
                cutAt[ply + 1] = pv ? true : !cutAt[ply];
                int red = 0;
                if (depth >= 3 && legal > 2 && !inCheck && !givesCheck && (quiet || badCap)) {
                    red = LMR[Math.min(depth, 63)][Math.min(legal, 63)];
                    if (pv) red--;
                    if (!improving) red++;
                    if (Params.LMR_CUT.val != 0 && cutAt[ply] && !pv) red++;
                    if (quiet) {
                        if (Params.LMR_HIST2.val != 0) red -= Math.max(-2, Math.min(2, hs / 5000));
                        else if (hs > 6000) red--;
                        else if (hs < -4000) red++;
                        if (m == killers[ply][0] || m == killers[ply][1] || m == counter) red--;
                        if (ttCap && Params.LMR_TT.val != 0) red++;
                    }
                    if (huntMove) red--;
                    if (red < 0) red = 0;
                    if (red > depth - 2) red = depth - 2;
                }
                score = -search(-alpha - 1, -alpha, d1 - red, ply + 1, true);
                if (score > alpha && red > 0) score = -search(-alpha - 1, -alpha, d1, ply + 1, true);
                if (score > alpha && score < beta) score = -search(-beta, -alpha, d1, ply + 1, true);
            }
            pos.unmake();
            if (stop) return 0;
            if (quiet && nq < 63) tried[nq++] = m;
            else if (!quiet && (Pos.flag(m) & Pos.F_CAP) != 0 && nc < 31) capsTried[ply][nc++] = m;
            if (score > best) {
                best = score; bestMove = m;
                if (root) { rootMove = m; rootScore = score; }
                if (score > alpha) {
                    alpha = score;
                    if (score >= beta) {
                        if (quiet) {
                            if (killers[ply][0] != m) { killers[ply][1] = killers[ply][0]; killers[ply][0] = m; }
                            if (prevMove != 0) cmv[Pos.from(prevMove)][Pos.to(prevMove)] = m;
                            int bonus = Math.min(1600, 36 * depth * depth);
                            int[] h = hist[side][Pos.from(m)];
                            h[Pos.to(m)] = gravity(h[Pos.to(m)], bonus);
                            for (int q = 0; q < nq - 1; q++) {
                                int qm = tried[q];
                                int[] hq = hist[side][Pos.from(qm)];
                                hq[Pos.to(qm)] = gravity(hq[Pos.to(qm)], -bonus);
                            }
                            if (cb >= 0) {
                                int ci = cb + (((pos.b[Pos.from(m)] & 7) << 7) | Pos.to(m));
                                contHist[ci] = gravity(contHist[ci], bonus);
                                for (int q = 0; q < nq - 1; q++) {
                                    int qm = tried[q];
                                    int qi = cb + (((pos.b[Pos.from(qm)] & 7) << 7) | Pos.to(qm));
                                    contHist[qi] = gravity(contHist[qi], -bonus);
                                }
                            }
                        } else if (useCapH && (Pos.flag(m) & Pos.F_CAP) != 0) {
                            int bonus = Math.min(1600, 36 * depth * depth);
                            int mi = capIdx(m);
                            capHist[mi] = gravity(capHist[mi], bonus);
                            for (int q = 0; q < nc - 1; q++) {
                                int qi = capIdx(capsTried[ply][q]);
                                capHist[qi] = gravity(capHist[qi], -bonus);
                            }
                        }
                        break;
                    }
                }
            }
        }
        if (legal == 0) return ex != 0 ? alpha : (inCheck ? -MATE + ply : (contempt == 0 ? 0 : drawVal(ply)));
        if (ex != 0) return best;
        final boolean sameKey = tKey[idx] == pos.key;
        if (!sameKey || depth + 2 >= tDepth[idx] || best > origAlpha && best < beta) {
            tKey[idx] = pos.key;
            if (bestMove != 0 || !sameKey) tMove[idx] = bestMove;
            tDepth[idx] = (byte) Math.min(depth, 100);
            tScore[idx] = (short) scoreToTT(best, ply);
            tFlag[idx] = (byte) (best >= beta ? 2 : best > origAlpha ? 1 : 3);
        }
        return best;
    }

    public static final class Result {
        public int move; public int score; public int depth; public long nodes;
    }

    /** Fikarohana mahazatra: iterative deepening hatramin'ny maxDepth na fotoana. */
    public Result think(int maxDepth, long moveTimeMs) {
        long t0 = System.nanoTime();
        deadline = t0 + moveTimeMs * 1_000_000L;
        double softF = 0.5; int lastBest = 0; int stable = 0;
        long softBase = moveTimeMs * 1_000_000L;
        stop = false; nodes = 0; rootMove = 0;
        contempt = Params.CONTEMPT.val != 0 ? Params.CONTEMPT.val : (Params.JORO_STYLE.val != 0 ? Params.JORO_CONTEMPT.val : 0);
        Result res = new Result();
        int[] ms = new int[256];
        int n = pos.genAll(ms);
        int cnt = 0, only = 0;
        for (int i = 0; i < n; i++) if (pos.make(ms[i])) { pos.unmake(); cnt++; only = ms[i]; }
        if (cnt == 0) return res;
        res.move = only;
        if (cnt == 1) { res.depth = 0; return res; }
        int prev = 0;
        for (int d = 1; d <= maxDepth && d < MAXPLY - 10; d++) {
            int alpha = -INF, beta = INF, delta = Params.ASP_DELTA.val;
            if (d >= 5) { alpha = prev - delta; beta = prev + delta; }
            int score;
            while (true) {
                score = search(alpha, beta, d, 0, false);
                if (stop) break;
                if (score <= alpha) { alpha = Math.max(-INF, alpha - delta); delta *= 2; if (delta > 800) alpha = -INF; }
                else if (score >= beta) { beta = Math.min(INF, beta + delta); delta *= 2; if (delta > 800) beta = INF; }
                else break;
            }
            if (stop) break;
            if (rootMove == lastBest) stable++; else { stable = 0; softF = 0.75; }
            lastBest = rootMove;
            if (stable >= 3) softF = 0.4;
            res.move = rootMove; res.score = score; res.depth = d; prev = score;
            if (Math.abs(score) > MATE_BOUND && d >= 6) break;
            if (System.nanoTime() > t0 + (long) (softBase * softF)) break;
        }
        res.nodes = nodes;
        lastDepth = res.depth;
        return res;
    }

    /** Fikarohana ho an'ny bot malemy: jerena daholo ny hetsika amin'ny depth voafetra, ampiana "tabataba" (centipawn). */
    public Result thinkWeak(int depth, int noiseCp, long moveTimeMs, Random rnd) {
        long t0 = System.nanoTime();
        deadline = t0 + moveTimeMs * 1_000_000L;
        stop = false; nodes = 0; contempt = 0;
        Result res = new Result();
        int[] ms = new int[256];
        int n = pos.genAll(ms);
        int bestMv = 0; double bestVal = -1e18; int bestScore = 0;
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            if (!pos.make(m)) continue;
            int s;
            s = -search(-INF, INF, Math.max(0, depth - 1), 1, true);
            pos.unmake();
            if (stop && bestMv != 0) break;
            if (stop) s = 0;
            double v = s;
            if (Math.abs(s) < MATE_BOUND) v += rnd.nextGaussian() * noiseCp;
            else if (s > 0) v += 5000; // mate azo: aza very very mba tsy hita
            if (v > bestVal) { bestVal = v; bestMv = m; bestScore = s; }
        }
        res.move = bestMv; res.score = bestScore; res.depth = depth; res.nodes = nodes;
        return res;
    }
}
