# JORO: motera manokana (HCE) nesorina tamin'ny app

Java pur (tsy misy Android/Kotlin), JDK 17+. `src/` = motera, `tools/` = fitaovana, `tests/` = fitsapana.

## Build
    ./build.sh      # -> joro.jar (UCI) sy build/cls

## Fampiasana  (C = mg.chess.offline.own)
    java -jar joro.jar                                    # UCI (cutechess-cli, lichess-bot...). Safidy: Eval2..Eval6, Elo (profile bot), Hash...
    java -cp build/cls $C.Bench 9 60 [Safidy=1 ...]       # nodes (famantarana ny search), nps, depth@60ms
    java -cp build/cls $C.Perft                           # tokony PASS (nodes=16989881)
    java -cp build/cls $C.SymTest [Eval6=1 ...]           # eval symmetry (mirror) tokony PASS
    java -cp build/cls $C.Match / SelfPlay                # fifaninanana / data Texel
    java -Dgroups=w5 -cp build/cls $C.Texel <out> <data>  # Texel (jereo workflows/texel.yml)

**Fototra bench (project-75):** `Bench 9 60` => nodes=**429554** (Eval5=1 default, Eval6=0). Miaraka amin'ny `Eval5=0` => 432893; `Eval6=1` => 470307. Raha miova ny nodes rehefa tsy nampiova search/eval intsony ianao, misy simba. Ny fanovana search dia mampiova ny nodes (mahazatra): ampitahao amin'ny SPRT.

## Rafitra
- `src/Search.java`: alpha-beta, TT, LMR, NMP, RFP/razor/futility, aspiration. Safidy search (`ProbCut`, `HistPrune`, `SeePrune`, `TtEval`... default 0) ao amin'ny `Params.java`.
- `src/Eval.java`: HCE; Eval2..Eval6 = vondrona toetra (`Params.EVALn`). Lanja voatombana ao amin'ny "Lanja voatombana" (`tools/apply_tuned.py`).
- `src/Params.java`: safidy UCI/SPSA/SPRT `reg(nom, default, min, max)`.
- `src/OwnBot.java`: fampiasana ao amin'ny app (profile Elo bot, `thinkFor`); `GambitBook`/`PgnBot`: bot toetra.
- `tools/*.py` + `workflows/*.yml`: SPRT, SPSA, Texel, calibrate vs Stockfish `UCI_Elo` (mila stockfish + python-chess). Ny lalana ao anatin'ny workflow dia natao ho an'ny repo taloha.
- `docs/OWN_ENGINE.md`: tantara project-60..75 sy valin'ny SPRT/Texel/calibrate rehetra.

## Valiny fototra (2026-11)
Hery feno ~2650-2690 ±40-60 (Stockfish UCI_Elo, 1500 ms). Eval5 default 1 (~+10 Elo). Eval6, ProbCut, HistPrune, SeePrune, TtEval: tsy misy tombony voaporofo (default 0).

## Fampiasana amin'ny app
Ny app dia mampiasa ny `src/*.java` mitovy (`app/src/main/java/mg/chess/offline/own/`). Rehefa vita ny fanovana: adikao any, ary jereo Bench/Perft aloha.
