# JORO ULTIMATE — Phase 1 initial implementation

## Scope
Added two independently tunable HCE evaluation terms:
- `KingPressure` (0..100, default 0): bounded additional king pressure using existing attacker units, pawn-shield holes, and available king flight squares.
- `SmartSac` (0..100, default 0): bounded compensation only when the attacker is materially behind, has at least three king-zone attackers, and the position indicates meaningful king danger / queen participation. Material deficit alone does not trigger it.

Both are disabled by default, so the default evaluation path is intended to preserve the previous engine behavior. `Search.java` and move ordering were deliberately not modified in this first patch: search-side sacrifice verification should follow after measuring this isolated evaluation feature.

## Validation performed locally
- `bash build.sh`: PASS
- `Perft`: PASS, 16,989,881 nodes
- `SymTest`: PASS, 12 FENs
- `Bench`: PASS, fixed-depth d9 = 429,554 nodes; time-limited average depth = 9.8

Bench timings are machine/JIT dependent and are not evidence of Elo improvement. No SPRT was run. Parameters remain 0 by default pending tuning and match tests.

## Review required
Have Claude Sonnet review:
1. integer bounds and score perspective in the new `Eval.java` terms;
2. whether `KingPressure` double-counts existing king danger;
3. whether `SmartSac` can reward materially unsound attacks;
4. UCI/SPSA parameter exposure and default-off equivalence.

Do not enable either parameter in a playing build until a controlled baseline comparison and SPRT support it.
