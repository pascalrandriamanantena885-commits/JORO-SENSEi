#!/usr/bin/env python3
"""Fampitahana vokatra EpdTest (taloha vs vaovao). Fampiasana: epdcmp.py <dir> -- mamaky epd-base-*.txt sy epd-new-*.txt"""
import sys, glob, re, os

def load(d, side):
    res = {}
    for f in sorted(glob.glob(os.path.join(d, f"epd-{side}-*.txt"))):
        for line in open(f, encoding="utf-8"):
            m = re.match(r"^(\S+?)\s+(OK|FAIL)\s+(\S+)", line.strip())
            if m: res[m.group(1)] = (m.group(2) == "OK", m.group(3))
    return res

def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    b, n = load(d, "base"), load(d, "new")
    if not b or not n:
        print("::error::Tsy hita ny vokatra epd-base/epd-new"); sys.exit(1)
    keys = sorted(set(b) | set(n))
    sb = sum(1 for k in b if b[k][0]); sn = sum(1 for k in n if n[k][0])
    out = ["### EPD taloha vs vaovao", "", "| | voavaha | total |", "|---|---|---|",
           f"| taloha | {sb} | {len(b)} |", f"| vaovao | {sn} | {len(n)} |", "",
           f"Diff: **{sn - sb:+d}**", ""]
    gained = [k for k in keys if k in b and k in n and n[k][0] and not b[k][0]]
    lost = [k for k in keys if k in b and k in n and b[k][0] and not n[k][0]]
    out.append(f"Voavaha vaovao fotsiny ({len(gained)}): " + (", ".join(gained) or "-"))
    out.append(f"Very (voavaha tamin'ny taloha) ({len(lost)}): " + (", ".join(lost) or "-"))
    out += ["", "_Fitsapana haingana ihany: tsy mamaly ny Elo. Ny SPRT no mamaritra ny hery._"]
    text = "\n".join(out)
    print(text)
    s = os.environ.get("GITHUB_STEP_SUMMARY")
    if s: open(s, "a", encoding="utf-8").write(text + "\n")

if __name__ == "__main__":
    main()
