package mg.chess.offline.own;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Fitsapana tactique EPD (WAC, ERET, sns.) amin'ny HCE an'i JORO ihany (tsy misy motera ivelany).
 * Mamaky ny opcode "bm" (best move) sy "am" (avoid move), SAN na UCI; tsy miankina amin'ny +#!?.
 *
 * Fampiasana:
 *   java -cp cls mg.chess.offline.own.EpdTest <file.epd>[,<file2.epd>...] [movetime=1000] [depth=64]
 *        [shard=0] [shards=1] [limit=0] [min=0] [out=epd.txt] [Name=val ...]
 *   movetime : ms isaky ny toerana (default 1000)       depth : depth faratampony (default 64)
 *   shard/shards : zarao ny toerana (i % shards == shard)   limit : toerana voalohany ihany (0 = rehetra)
 *   min : raha latsaky ny N ny voavaha dia exit code 1 (0 = tsy misy fepetra)
 *   out : rakitra vokatra isaky ny toerana ("id OK|FAIL move")
 *   Name=val : safidy UCI/Params (ohatra SacVerify=1 KingPressure=30)
 * Raha mitovy ny depth sy tsy voafetra ny fotoana (movetime lehibe), mitovy foana ny vokatra (azo averina).
 */
public class EpdTest {

    static String san(Pos p, int m, int[] legal, int nl) {
        int f = Pos.from(m), t = Pos.to(m);
        int pt = p.b[f] & 7;
        if ((Pos.flag(m) & Pos.F_CASTLE) != 0) return (t & 7) > (f & 7) ? "O-O" : "O-O-O";
        boolean cap = (Pos.flag(m) & (Pos.F_CAP | Pos.F_EP)) != 0 || p.b[t] != 0;
        StringBuilder sb = new StringBuilder();
        if (pt == Pos.P) {
            if (cap) sb.append((char) ('a' + (f & 7))).append('x');
            sb.append(Pos.sqName(t));
            if (Pos.promo(m) != 0) sb.append('=').append("NBRQ".charAt(Pos.promo(m) - 2));
        } else {
            sb.append("NBRQK".charAt(pt - 2));
            boolean amb = false, sameFile = false, sameRank = false;
            for (int i = 0; i < nl; i++) {
                int o = legal[i];
                if (o == m || Pos.to(o) != t || Pos.from(o) == f || (p.b[Pos.from(o)] & 7) != pt) continue;
                amb = true;
                if ((Pos.from(o) & 7) == (f & 7)) sameFile = true;
                if ((Pos.from(o) >> 4) == (f >> 4)) sameRank = true;
            }
            if (amb) {
                if (!sameFile) sb.append((char) ('a' + (f & 7)));
                else if (!sameRank) sb.append((char) ('1' + (f >> 4)));
                else sb.append(Pos.sqName(f));
            }
            if (cap) sb.append('x');
            sb.append(Pos.sqName(t));
        }
        return sb.toString();
    }

    static String norm(String s) {
        return s.replaceAll("[+#!?]", "").replace("0-0-0", "O-O-O").replace("0-0", "O-O").replace("=", "").trim();
    }

    static boolean matches(Pos p, int m, int[] legal, int nl, String tok) {
        String a = norm(tok), b = norm(san(p, m, legal, nl));
        if (a.equals(b)) return true;
        return a.equalsIgnoreCase(Pos.moveStr(m));     // UCI
    }

    /** Opcodes: "bm Qg6 Rxf7; id \"WAC.001\";" - tsy mizara ny ';' ao anaty "". */
    static List<String[]> opcodes(String s) {
        List<String[]> r = new ArrayList<>();
        StringBuilder cur = new StringBuilder(); boolean q = false;
        for (char c : s.toCharArray()) {
            if (c == '"') q = !q;
            if (c == ';' && !q) { add(r, cur.toString()); cur.setLength(0); } else cur.append(c);
        }
        add(r, cur.toString());
        return r;
    }
    static void add(List<String[]> r, String x) {
        x = x.trim(); if (x.isEmpty()) return;
        int i = x.indexOf(' ');
        r.add(i < 0 ? new String[]{x, ""} : new String[]{x.substring(0, i), x.substring(i + 1).trim()});
    }

    public static void main(String[] a) throws IOException {
        String files = null; long mt = 1000; int depth = 64, shard = 0, shards = 1, limit = 0, min = 0; String out = null;
        for (String s : a) {
            int e = s.indexOf('=');
            if (e < 0) { files = s; continue; }
            String k = s.substring(0, e), v = s.substring(e + 1);
            switch (k) {
                case "movetime": mt = Long.parseLong(v); break;
                case "depth": depth = Integer.parseInt(v); break;
                case "shard": shard = Integer.parseInt(v); break;
                case "shards": shards = Integer.parseInt(v); break;
                case "limit": limit = Integer.parseInt(v); break;
                case "min": min = Integer.parseInt(v); break;
                case "out": out = v; break;
                default:
                    if (Params.set(k, Integer.parseInt(v))) System.out.println("OPTION " + s);
                    else { System.out.println("OPTION TSY MARINA: " + s); System.exit(2); }
            }
        }
        if (files == null) { System.out.println("Fampiasana: EpdTest file.epd[,file2.epd] [movetime=] [depth=] [shard=] [shards=] [limit=] [min=] [out=] [Name=val]"); System.exit(2); }
        PrintWriter pw = out != null ? new PrintWriter(Files.newBufferedWriter(Paths.get(out), StandardCharsets.UTF_8)) : null;
        int solved = 0, total = 0, bad = 0; long nodes = 0, spent = 0;
        for (String file : files.split(",")) {
            int fs = 0, ft = 0, idx = 0;
            for (String line : Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#") || line.startsWith("//")) continue;
                if (limit > 0 && idx >= limit) break;
                if ((idx++ % shards) != shard) continue;
                String[] t = line.split("\\s+", 5);
                if (t.length < 4) { System.out.println("EPD diso: " + line); bad++; continue; }
                String fen = t[0] + " " + t[1] + " " + t[2] + " " + t[3] + " 0 1";
                String rest = t.length > 4 ? t[4] : "";
                String id = "?"; List<String> bm = new ArrayList<>(), am = new ArrayList<>();
                for (String[] op : opcodes(rest)) {
                    if (op[0].equals("bm")) for (String x : op[1].split("\\s+")) bm.add(x);
                    else if (op[0].equals("am")) for (String x : op[1].split("\\s+")) am.add(x);
                    else if (op[0].equals("id")) id = op[1].replace("\"", "");
                }
                if (bm.isEmpty() && am.isEmpty()) { System.out.println("Tsy misy bm/am: " + line); bad++; continue; }
                Search s = new Search(new Eval(50, 50, 50, 50, 50));
                s.setHash(Params.HASH_BITS.val);
                if (!s.pos.setFen(fen)) { System.out.println("FEN diso: " + fen); bad++; continue; }
                int[] all = new int[256]; int n = s.pos.genAll(all);
                int[] legal = new int[256]; int nl = 0;
                for (int i = 0; i < n; i++) if (s.pos.make(all[i])) { s.pos.unmake(); legal[nl++] = all[i]; }
                long c0 = System.nanoTime();
                Search.Result r = s.think(depth, mt);
                spent += System.nanoTime() - c0; nodes += r.nodes;
                boolean ok = r.move != 0;
                if (ok && !bm.isEmpty()) { ok = false; for (String x : bm) if (matches(s.pos, r.move, legal, nl, x)) ok = true; }
                if (ok) for (String x : am) if (matches(s.pos, r.move, legal, nl, x)) ok = false;
                String ms = r.move == 0 ? "0000" : san(s.pos, r.move, legal, nl);
                ft++; total++; if (ok) { fs++; solved++; }
                String lineOut = String.format("%s %s %s (bm=%s am=%s d=%d nodes=%d)", id, ok ? "OK" : "FAIL", ms, bm, am, r.depth, r.nodes);
                if (!ok) System.out.println("  " + lineOut);
                if (pw != null) pw.println(file + ":" + lineOut);
            }
            System.out.printf("EPD_FILE %s solved=%d total=%d%n", file, fs, ft);
        }
        if (pw != null) pw.close();
        System.out.printf("EPD_SUMMARY solved=%d total=%d pct=%.1f invalid=%d nodes=%d time=%dms movetime=%d depth=%d shard=%d/%d%n",
            solved, total, total > 0 ? 100.0 * solved / total : 0, bad, nodes, spent / 1_000_000L, mt, depth, shard, shards);
        if (bad > 0 || (min > 0 && solved < min)) System.exit(1);
    }
}
