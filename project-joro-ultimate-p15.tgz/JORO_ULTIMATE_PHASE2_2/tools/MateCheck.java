package mg.chess.offline.own;

import java.util.Random;

/**
 * Fanamarinana ny Mate solver (soundness): amin'ny toerana kisendrasendra, raha mitaky mat ao amin'ny k hetsika ny solver
 * dia tsy maintsy hita ihany koa ny mat ao amin'ny k hetsika (<= 2k-1 ply) amin'ny search feno (MateSolver=0).
 * Fampiasana: java -cp cls mg.chess.offline.own.MateCheck [positions=3000] [seed=1] [K=3] [dump=file.epd]
 * Vokatra: MATECHECK claims=N sound=N unsound=N byK=[..] solverMs=.. ; exit 1 raha misy unsound.
 */
public class MateCheck {
    public static void main(String[] a) throws Exception {
        int positions = 3000, K = 3; long seed = 1; String dump = null; boolean recall = false; int recallBrute = 0, recallHit = 0, recallMissQ = 0;
        for (String s : a) {
            String[] kv = s.split("=");
            if (kv[0].equals("positions")) positions = Integer.parseInt(kv[1]);
            else if (kv[0].equals("seed")) seed = Long.parseLong(kv[1]);
            else if (kv[0].equals("K")) K = Integer.parseInt(kv[1]);
            else if (kv[0].equals("dump")) dump = kv[1];
            else if (kv[0].equals("recall")) recall = kv[1].equals("1");
        }
        Params.set("MateSolverDepth", K); Params.set("MateSolverQuiet", 1); Params.set("MateSolverMs", 60);
        Random rnd = new Random(seed);
        int claims = 0, unsound = 0, checked = 0; int[] byK = new int[10]; long solverNs = 0;
        java.io.PrintWriter pw = dump != null ? new java.io.PrintWriter(dump) : null;
        int idx = 0;
        for (int g = 0; checked < positions; g++) {
            Pos p = new Pos(); p.startPos();
            int plies = 20 + rnd.nextInt(80);
            int[] ms = new int[256];
            for (int ply = 0; ply < plies; ply++) {
                int n = p.genAll(ms); int[] legal = new int[n]; int nl = 0;
                for (int i = 0; i < n; i++) if (p.make(ms[i])) { p.unmake(); legal[nl++] = ms[i]; }
                if (nl == 0) break;
                // koa tsindry kely ny fakana sy check mba hisy toerana tactique
                int m = legal[rnd.nextInt(nl)];
                for (int t = 0; t < 2; t++) { int c = legal[rnd.nextInt(nl)]; if ((Pos.flag(c) & Pos.F_CAP) != 0) { m = c; break; } }
                p.make(m);
                if (ply > 14 && ply % 6 == 0) {
                    String fen = fenOf(p);
                    Search s = new Search(new Eval(50, 50, 50, 50, 50)); s.setHash(16);
                    if (!s.pos.setFen(fen)) continue;
                    checked++;
                    long t0 = System.nanoTime();
                    Search.Result r = s.solveMate(2000);
                    solverNs += System.nanoTime() - t0;
                    if (recall) {   // brute force k<=2: mat inona no tsy hitan'ny solver?
                        Search b = new Search(new Eval(50, 50, 50, 50, 50)); b.setHash(16); b.pos.setFen(fen);
                        boolean bf = full(b.pos, 1, 0) || full(b.pos, 2, 0);
                        if (bf) { recallBrute++; if (r.move != 0) recallHit++; }
                    }
                    if (r.move == 0) continue;
                    claims++;
                    int k = (r.depth + 1) / 2; byK[k]++;
                    // fanamarinana feno (brute force: hetsika rehetra ho an'ny roa tonta, tsy misy pruning)
                    Search f = new Search(new Eval(50, 50, 50, 50, 50)); f.setHash(16); f.pos.setFen(fen);
                    Search.Result fr = new Search.Result();
                    boolean sound = full(f.pos, k, 0);
                    fr.move = r.move; fr.score = sound ? Search.MATE : 0;
                    if (!sound) { unsound++; System.out.println("UNSOUND k=" + k + " " + fen + " solver=" + Pos.moveStr(r.move) + " full=" + Pos.moveStr(fr.move) + " score=" + fr.score); }
                    if (pw != null) pw.println(fen.replaceAll(" \\d+ \\d+$", "") + " bm " + Pos.moveStr(r.move) + "; id \"mate" + k + "." + (++idx) + "\";");
                }
            }
        }
        if (pw != null) pw.close();
        System.out.printf("MATECHECK positions=%d claims=%d sound=%d unsound=%d byK=%s solverMs=%d%n", checked, claims, claims - unsound,
            unsound, java.util.Arrays.toString(byK), solverNs / 1_000_000L);
        if (recall) System.out.printf("RECALL brute_mate_le2=%d solver_found=%d%n", recallBrute, recallHit);
        if (unsound > 0) System.exit(1);
    }

    static final int[][] BUF = new int[40][256];
    /** Brute force: mpanafika miandry, manana rem hetsika. */
    static boolean full(Pos p, int rem, int ply) {
        int[] ms = BUF[ply]; int n = p.genAll(ms);
        for (int i = 0; i < n; i++) {
            if (!p.make(ms[i])) continue;
            boolean ok = defFull(p, rem - 1, ply + 1);
            p.unmake();
            if (ok) return true;
        }
        return false;
    }
    static boolean defFull(Pos p, int remAfter, int ply) {
        int[] ms = BUF[ply]; int n = p.genAll(ms); int legal = 0;
        for (int i = 0; i < n; i++) {
            if (!p.make(ms[i])) continue;
            legal++;
            boolean ok = remAfter > 0 && full(p, remAfter, ply + 1);
            p.unmake();
            if (!ok) return false;
        }
        return legal == 0 ? p.inCheck() : true;
    }

    static String fenOf(Pos p) {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                int pc = p.b[r * 16 + f];
                if (pc == 0) { e++; continue; }
                if (e > 0) { sb.append(e); e = 0; }
                char c = "?PNBRQK".charAt(pc & 7);
                sb.append((pc >> 3) == 0 ? c : Character.toLowerCase(c));
            }
            if (e > 0) sb.append(e);
            if (r > 0) sb.append('/');
        }
        sb.append(p.side == 0 ? " w " : " b ");
        String c = "";
        if ((p.castle & 1) != 0) c += "K"; if ((p.castle & 2) != 0) c += "Q"; if ((p.castle & 4) != 0) c += "k"; if ((p.castle & 8) != 0) c += "q";
        sb.append(c.isEmpty() ? "-" : c).append(' ');
        sb.append(p.ep >= 0 ? Pos.sqName(p.ep) : "-").append(" 0 1");
        return sb.toString();
    }
}
