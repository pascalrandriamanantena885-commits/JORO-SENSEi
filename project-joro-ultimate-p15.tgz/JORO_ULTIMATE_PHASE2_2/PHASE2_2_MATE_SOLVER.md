# Phase 2.2 - Mate solver (opt-in, default MateSolver=0)

## What
Forcing search at the root (before iterative deepening): attacker (side to move) plays checking moves only
(first move may be quiet if MateSolverQuiet=1 = "block escape square first"), defender tries ALL legal replies.
If a forced mate within MateSolverDepth moves exists, it is played directly (score MATE-(2k-1)).
Independent of Eval; sacrifices (even queen/rook) are validated because the mate is exhaustively proven.
"Not found" does NOT mean "no mate" (quiet moves after the first are not tried).

## Params
MateSolver (0/1, default 0) | MateSolverDepth (1..8, default 4) | MateSolverQuiet (0/1, default 1) | MateSolverMs (% of movetime, default 30)

## Validation (local)
- MateSolver=0: bench/perft/sym identical to Phase 1.3 (429,554 nodes @ d9).
- tools/MateCheck.java: soundness vs brute-force full-width search: 53/53 claims sound (seed 1, K=3, 3005 positions);
  recall for mate<=2 (quiet root allowed): 35/35 (seed 7, 1503 positions).
- tests/mate.epd: 53 self-generated positions, mate in 1-3, each verified sound by brute force.
  NOTE: selected where the solver finds a mate, so 100% solver score is by construction; the useful number is the plain search:
  41/53 (77%) at 200 ms. Not an independent suite and not a strength measure.
- Cost when enabled: bench nodes @ d9 429,554 -> 479,528 (+11.6%) because the solver spends nodes in positions with no mate.
  No Elo claimed. Needs SPRT: opts_base="" vs variant "MateSolver=1" (and MateSolverDepth=3/5).
## Next (P2.3): gate the solver by enemy-king exposure (escape squares, checks available) to cut the idle cost; integrate inside search.
