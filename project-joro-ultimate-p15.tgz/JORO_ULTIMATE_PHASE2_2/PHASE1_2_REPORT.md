# JORO ULTIMATE — Phase 1.2: Search-side Sacrifice Verification

## Scope
Implemented a conservative, opt-in Search feature in `src/Search.java`, controlled by the new UCI/SPSA parameter `SacVerify` in `src/Params.java`.

### Behaviour
- `SacVerify=0` by default: the new path is disabled and the previous default search behavior is preserved.
- When enabled, a negative-SEE capture is treated only as a *candidate* sacrifice if it has an initial tactical signal (king-zone proximity under `JoroHunt`, or a rook line/contact after making the move).
- The move is not automatically rewarded and does not receive a bonus merely for sacrificing material.
- After the move is made, it is considered verified only if it gives check or creates an actual rook line/contact against the enemy king.
- A verified sacrifice avoids late-move reduction, so the normal alpha-beta search checks the opponent's best replies at full depth.
- A verified checking sacrifice may receive one bounded extension (`depth >= 5`, `ply <= 20`). Rook-contact alone does not receive an extension.
- Existing pruning behavior remains active for unverified sacrifices.

## Validation performed locally
- `bash build.sh`: PASS
- Perft: PASS, 16,989,881 nodes
- Symmetry: PASS, 12 FENs
- Fixed-depth Bench: PASS, 429,554 nodes at depth 9 (same node count as Phase 1 baseline)
- Time-limited Bench: average depth 9.8; timings are machine/JIT dependent
- UCI handshake: PASS; `SacVerify` appears as a spin option (default 0)
- UCI smoke test with `SacVerify=1`: PASS; engine returned a legal `bestmove`

## Limitations / next validation
- No Elo improvement is claimed. No SPRT or gauntlet has been run for this patch.
- The feature is opt-in and should remain disabled in the playing default until controlled matches show a benefit.
- Review the candidate gate and the full-depth/extension behavior with Claude Sonnet, then run a paired baseline-vs-candidate SPRT with identical time control, opening set, hash, threads, and adjudication.
- If node growth is excessive, test the no-extension variant separately before changing the candidate gate.
