# JORO ULTIMATE — PHASE 1 + PHASE 1.2

Ity archive ity dia mampiditra ny Attack Intelligence (Phase 1) sy Search-side Sacrifice Verification (Phase 1.2).

## Paramètres UCI vaovao
- `KingPressure` (default 0)
- `SmartSac` (default 0)
- `SacVerify` (default 0)

Default 0 no napetraka mba hitazonana ny baseline rehefa tsy manao tuning. Alefaso tsirairay ihany ireo paramètres rehefa manao SPSA/SPRT.

## Fanamarinana natao tamin'ity build ity
- Compilation: PASS
- Perft suite: PASS, 16,989,881 nodes
- Symmetry test: PASS, 12 FENs
- UCI options: hita ny KingPressure, SmartSac ary SacVerify

Tsy mbola manaporofo fiakaran'ny Elo ireo fitsapana ireo. Ilaina ny tuning sy SPRT amin'ny match voafehy.

## Build
JDK 17+:
```bash
bash build.sh
```

## Fanamarihana
Ny `.patch` files dia natao ho reference/review; ny source efa tafiditra mivantana ao amin'ny `src/`.
