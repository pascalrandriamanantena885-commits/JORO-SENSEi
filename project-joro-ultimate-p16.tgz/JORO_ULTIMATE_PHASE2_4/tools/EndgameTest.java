package mg.chess.offline.own;

import java.util.Random;

/**
 * Fitsapana fanaovana mat amin'ny endgame tsotra (KQK, KRK, KBNK, KBBK, KRRK): mpilalao roa samy JORO.
 * Fampiasana: java -cp cls mg.chess.offline.own.EndgameTest [type=KQK,KRK,KBNK,KBBK] [n=30] [movetime=20] [depth=64] [seed=1] [maxply=200] [Name=val ...]
 * Ho an'ny vokatra azo averina: depth=8 movetime=60000 (tsy miankina amin'ny fotoana/CPU).
 * Vokatra: ENDGAME <type> mate=N stalemate=N draw50=N rep=N unfinished=N avg_ply=X
 * Miova ny vokatra araka ny Eval/Params: azo ampiasaina hampitahana taloha vs vaovao (seed mitovy = toerana mitovy).
 */
public class EndgameTest {
    static final String[] PIECES = {"", "", "N", "B", "R", "Q"};

    static String randomFen(String type, Random rnd) {
        // type: K + pieces + K  (ohatra KBNK = fotsy: K,B,N ; mainty: K)
        for (int tries = 0; tries < 1000; tries++) {
            char[] bd = new char[64];
            java.util.Arrays.fill(bd, '.');
            java.util.List<Character> ps = new java.util.ArrayList<>();
            ps.add('K');
            for (int i = 1; i < type.length() - 1; i++) ps.add(type.charAt(i));
            ps.add('k');
            int[] sq = new int[ps.size()];
            boolean ok = true;
            for (int i = 0; i < ps.size(); i++) {
                int s; int g = 0;
                do { s = rnd.nextInt(64); g++; } while (bd[s] != '.' && g < 100);
                bd[s] = ps.get(i); sq[i] = s;
            }
            int wk = sq[0], bk = sq[ps.size() - 1];
            if (type.equals("KBBK")) {
                int b1 = -1, b2 = -1;
                for (int i = 0; i < 64; i++) if (bd[i] == 'B') { if (b1 < 0) b1 = i; else b2 = i; }
                if ((((b1 & 7) + (b1 >> 3)) & 1) == (((b2 & 7) + (b2 >> 3)) & 1)) continue;
            }
            if (Math.abs((wk & 7) - (bk & 7)) <= 1 && Math.abs((wk >> 3) - (bk >> 3)) <= 1) continue;
            StringBuilder sb = new StringBuilder();
            for (int r = 7; r >= 0; r--) {
                int e = 0;
                for (int f = 0; f < 8; f++) { char c = bd[r * 8 + f]; if (c == '.') e++; else { if (e > 0) { sb.append(e); e = 0; } sb.append(c); } }
                if (e > 0) sb.append(e);
                if (r > 0) sb.append('/');
            }
            String fen = sb + " w - - 0 1";
            Pos p = new Pos();
            if (!p.setFen(fen)) continue;
            if (p.attacked(p.ksq[1], 0)) continue;           // mpanjaka mainty tsy tokony ho voatafika (fotsy no mihetsika)
            if (p.inCheck()) continue;
            return fen;
        }
        throw new IllegalStateException("tsy afaka namorona toerana " + type);
    }

    public static void main(String[] a) {
        String types = "KQK,KRK,KBNK,KBBK"; int n = 30, maxply = 200; long mt = 20, seed = 1; int depth = 64;
        for (String s : a) {
            int e = s.indexOf('=');
            String k = s.substring(0, e), v = s.substring(e + 1);
            switch (k) {
                case "type": types = v; break;
                case "n": n = Integer.parseInt(v); break;
                case "movetime": mt = Long.parseLong(v); break;
                case "depth": depth = Integer.parseInt(v); break;
                case "seed": seed = Long.parseLong(v); break;
                case "maxply": maxply = Integer.parseInt(v); break;
                default: if (!Params.set(k, Integer.parseInt(v))) { System.out.println("OPTION TSY MARINA: " + s); System.exit(2); }
            }
        }
        for (String type : types.split(",")) {
            Random rnd = new Random(seed);
            int mate = 0, stale = 0, d50 = 0, rep = 0, unf = 0; long plies = 0;
            for (int g = 0; g < n; g++) {
                String fen = randomFen(type, rnd);
                Search s = new Search(new Eval(50, 50, 50, 50, 50)); s.setHash(18); s.pos.setFen(fen);
                int ply = 0; String res = "unf";
                while (ply < maxply) {
                    int[] ms = new int[256]; int cnt = s.pos.genAll(ms), legal = 0;
                    for (int i = 0; i < cnt; i++) if (s.pos.make(ms[i])) { s.pos.unmake(); legal++; }
                    if (legal == 0) { res = s.pos.inCheck() ? "mate" : "stale"; break; }
                    if (s.pos.half >= 100) { res = "d50"; break; }
                    if (s.pos.repeated()) { res = "rep"; break; }
                    Search.Result r = s.think(depth, mt);
                    if (r.move == 0 || !s.pos.make(r.move)) { res = "unf"; break; }
                    ply++;
                }
                plies += ply;
                switch (res) { case "mate": mate++; break; case "stale": stale++; break; case "d50": d50++; break; case "rep": rep++; break; default: unf++; }
            }
            System.out.printf("ENDGAME %s mate=%d stalemate=%d draw50=%d rep=%d unfinished=%d n=%d avg_ply=%.1f%n", type, mate, stale, d50, rep, unf, n, plies / (double) n);
        }
    }
}
