# Phase 2.4 - Endgame (all opt-in, default 0 => Eval/Search unchanged)

## Params
- MopUp2 (0..200, %): mop-up vaovao rehefa pawnless ny very ary mpandresy >=300cp, phase<=8.
  KBNK: ny mpanjaka very entina any amin'ny zoro misy loko mitovy amin'ny bishop; hafa: edge/zoro + akaikin'ny mpanjaka, gradient matanjaka kokoa.
- PawnSafe (0..200, %): passer (rr>=3): square eo alohan'ny pawn voaro (tsy voatafika) = bonus; voatafika ary tsy voaro = penalty.
- UnstopBonus (0..800 cp): passer tsy azo atsahatra (fitsipika ny efamira, mpifanandrina tsy manana piece, lalana madio) = bonus ~ rr/6.
- DrawSeek (0..100 cp) / DrawSeekFrom (default 150): rehefa very (score <= -From) dia contempt ratsy (mitady draw).

## Validation (local)
- Defaults: Bench 429,554 nodes @d9 (unchanged), Perft PASS 16,989,881, SymTest PASS (also with all params on).
- Mirror test: 4,968 random endgame positions (KBNK, KBBK, KRK, KQK, KRPK, KBPK, KPPK, KNPK, KQPK, KRRPK): evalRaw(pos)==evalRaw(mirror) with params off AND on (0 asymmetries).
- tools/EndgameTest.java (both sides JORO, fixed depth => reproducible), 40 random positions, depth 8, seed 2:
    mate (of 40)       MopUp2=0  =100  =150  =200
    KBNK                   7      27    26    34
    KBBK (opp. colors)    33      37    37    37
    KRK                   40      40    40    40
    KQK                   40      40    40    40
  KBNK: 50-move draws 29 -> 5/13/3. KRK/KQK: mates are slightly shorter. Recommended: MopUp2=150..200.
- PawnSafe, UnstopBonus, DrawSeek: verified only for symmetry + neutrality at 0. DrawSeek showed no visible effect in KQK/KRK/KBNK
  (losing side has no real drawing resources there). They need SPRT; NO Elo claimed for any param.
## Notes
- randomFen for KBBK forces opposite-coloured bishops (same colour = theoretical draw).
- Results with movetime (not depth) are noisy (CPU load): use depth=8 movetime=60000.
