# Phase 1.3 - review fixes
- #1: SacVerify=0 now keeps the exact legacy `hext` rule (JoroHunt/JoroRook unchanged). Verified: identical bench nodes vs baseline for default, JoroHunt=1, JoroRook=1, JoroHunt+JoroRook+JoroStyle.
- #3: hext/LMR logic of SacVerify=1 isolated in its own branch; red=0 only matters for non-check rook-contact (checks are never LMR-reduced).
- Not changed: candidate gate overlap (rookGambit == verified rook contact), KingPressure/SmartSac overlap with existing danger/sacrifice bonuses.
- No Elo claimed. Next: separate SPRTs (SacVerify=1, KingPressure=30, SmartSac=30) vs baseline.
